<?php 
   
   include '../components/connect.php';

   if (isset($_COOKIE['user_id'])) {
      $user_id = $_COOKIE['user_id'];
   }else{
      $user_id = '';
      
   }


   if (isset($_POST['add_patient'])) {
      
      $id = unique_id();

      $name = $_POST['name'];
      $name = filter_var($name, FILTER_SANITIZE_STRING);

      $email = $_POST['email'];
      $email = filter_var($email, FILTER_SANITIZE_STRING);

      $contact = $_POST['contact'];
      $contact = filter_var($contact, FILTER_SANITIZE_STRING);

      $gender = $_POST['gender'];
      $gender = filter_var($gender, FILTER_SANITIZE_STRING);

      $dob = $_POST['dob'];
      $dob = filter_var($dob, FILTER_SANITIZE_STRING);

      $blood_group = $_POST['blood_group'];
      $blood_group = filter_var($blood_group, FILTER_SANITIZE_STRING);

      $marital_status = $_POST['marital_status'];
      $marital_status = filter_var($marital_status, FILTER_SANITIZE_STRING);

      $pass = sha1($_POST['pass']);
      $pass = filter_var($pass, FILTER_SANITIZE_STRING);

      $cpass = sha1($_POST['cpass']);
      $cpass = filter_var($cpass, FILTER_SANITIZE_STRING);

      if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
         $image = $_FILES['image']['name'];
         $image = filter_var($image, FILTER_SANITIZE_STRING);
         $ext = pathinfo($image, PATHINFO_EXTENSION);
         $rename = unique_id().'.'.$ext;
         $image_tmp_name = $_FILES['image']['tmp_name'];
         $image_folder = '../uploaded_files/'.$rename;

         move_uploaded_file($image_tmp_name, $image_folder);
      }else{
         $rename = 'default_profile.jpg';
         $image_folder = '../uploaded_files/'.$rename; //default image path
      }

      $status = 'pending';

      $select_patients = $conn->prepare("SELECT * FROM `patients` WHERE email = ?");
      $select_patients->execute([$email]);

      if ($select_patients->rowCount() > 0) {
         $warning_msg[] = 'email already taken';
      }else{
         $insert_patient = $conn->prepare("INSERT INTO `patients`(id, name, email, password, status, gender, contact, dob, marital_status, blood_group, profile) VALUES(?,?,?,?,?,?,?,?,?,?,?)");

         $insert_patient->execute([$id, $name, $email, $cpass, $status, $gender, $contact, $dob, $marital_status, $blood_group, $rename]);

         move_uploaded_file($image_tmp_name, $image_folder);
         echo "<script>
            alert('patient registered successfully. Redirecting to login page...');
            window.location.href = 'login.php';
            </script>
         ";
         exit();
      }
   }

?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Patient Registration</title>

   <!-- box icon cdn link  -->
   <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
   <link rel="stylesheet" type="text/css" href="../css/user_style.css?v=<?php echo "time"; ?>">

   <!-- Add CSS for intl-tel-input -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.min.css">

   <!-- Add JavaScript for intl-tel-input -->
   <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>

   <!-- You can optionally add this to get better number formatting -->
   <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js"></script>

   

</head>
<body>
   
   
<!-- register section starts  -->

<div class="form-container form">
   <form action="" method="post" enctype="multipart/form-data" class="register" onsubmit="getPhoneNumber()">
      <h3>Patient registration</h3>
      <div class="flex">
         <div class="col">
            <div class="input-field">
               <p>name<span>*</span></p>
               <input type="text" name="name" placeholder="Enter your name" maxlength="50" required class="box">
            </div>
            <div class="input-field">
               <p>contact number<span>*</span></p>
               <input type="tel" id="contact" name="contact" placeholder="Enter contact number" required class="box">
            </div>
            <div class="input-field">
               <p>email<span>*</span></p>
               <input type="email" name="email" placeholder="Enter your email" maxlength="70" required class="box">
            </div>
            <div class="input-field">
               <p>Select gender<span>*</span></p>
               <select name="gender" class="box select">
                  <option selected disabled>Select gender</option>
                  <option value="male">male</option>
                  <option value="female">female</option>
                  <option value="other">other</option>
               </select>
            </div>
            <div class="input-field">
               <p>Date of Birth<span>*</span></p>
               <input type="date" name="dob" placeholder="enter your dob" maxlength="70" required class="box">
            </div>
         </div>
         <div class="col">
            <div class="input-field">
               <p>Blood group<span>*</span></p>
               <select name="blood_group" class="box select">
                  <option selected disabled>Select blood group</option>
                  <option value="O positve">O positive</option>
                  <option value="O negative">O negative</option>
                  <option value="A positive">A positive</option>
                  <option value="A negative">A negative</option>
                  <option value="B positive">B positive</option>
                  <option value="B negative">B positive</option>
                  <option value="AB positive">AB positive</option>
                  <option value="AB negative">AB negative</option>
               </select>
            </div>
            <div class="input-field">
               <p>status<span>*</span></p>
               <select name="marital_status" class="box select">
                  <option selected disabled>Select status</option>
                  <option value="Single">Single</option>
                  <option value="Married">Married</option>
                  <option value="Unmarried">Unmarried</option>
                  <option value="Widow">Widow</option>
               </select>
            </div>
            <div class="input-field">
               <p>Password<span>*</span></p>
               <input type="password" name="pass" placeholder="Enter your password" maxlength="50" required class="box">
            </div>
            <div class="input-field">
               <p>Confirm password<span>*</span></p>
               <input type="password" name="cpass" placeholder="Confirm password" maxlength="50" required class="box">
            </div>
            <div class="input-field">
               <p>Select profile<span>*</span></p>
               <input type="file" name="image" accept="image/*" required class="box">
            </div>
         </div>
      </div>
      <p>already have an account?<a href="patient/login.php">login now</a></p>
      <button type="submit" name="add_patient" class="btn">register now</button>
   </form>
</div>

<!-- register section ends -->




   <!-- custom js link  -->
   <script type="text/javascript" src="../js/admin_script.js"></script>

   <?php include '../components/alert.php'; ?>
   

   <script>
      //used to display all country ip
      var input = document.querySelector("#contact");
      var iti = intlTelInput(input, {
         initialCountry: "auto", // Auto-detect the country based on the user's IP
         geoIpLookup: function(callback) {
            fetch("https://ipinfo.io", { headers: { "Accept": "application/json" } })
               .then(response => response.json())
               .then(data => callback(data.country)); // Auto-detect country
         },
         utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js" // Optional, for formatting
      });

   // When the form is submitted, capture the number with the country code
   function getPhoneNumber() {
      const phoneNumber = iti.getNumber(); // This will return the number with the country code
      document.getElementById('contact').value = phoneNumber; // For debugging
      // You can submit this phone number along with the rest of the form data
      return true;
   }
</script>
   
         
  
</body>
</html>