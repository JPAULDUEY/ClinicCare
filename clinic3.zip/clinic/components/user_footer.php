<!-- Newsletter Section -->
<div class="newsletter">
  <div class="box-detail">
    <h1>Subscribe to our Newsletter</h1>
    <p>A place of hope, healing, and compassion.
    Together, we care for your well-being.</p>
    <div class="input-field">
      <input type="email" placeholder="Enter your email..." class="box">
      <button class="btn">Subscribe</button>
    </div>
    <div class="icons">
      <i class="bx bxl-facebook"></i>
      <i class="bx bxl-instagram-alt"></i>
      <i class="bx bxl-linkedin"></i>
      <i class="bx bxl-twitter"></i>
      <i class="bx bxl-pinterest-alt"></i>
    </div>
  </div>
</div>

<!-- Footer Section -->
<footer class="site-footer">
  <div class="container">
    <div class="brand">
      <img src="components/image/cliniccare.png" width="160" alt="ClinicCare">
      <p>Compassionate care for every family member.</p>
    </div>
    <div class="links">
      <h3>Navigation</h3>
      <a href="home.php">Home</a>
      <a href="about.php">About</a>
      <a href="login.php">Login</a>
    </div>
    <div class="contact">
      <h3>Contact</h3>
      <p><i class="bx bxs-phone"></i> +63 969 045 1477</p>
      <p><i class="bx bx-envelope"></i> cliniccare@gmail.com</p>
      <p><i class="bx bx-map"></i> Dagupan City, Philippines</p>
    </div>
  </div>
  <div class="bottom">
    <p>© <?php echo date('Y'); ?> ClinicCare. All rights reserved.</p>
  </div>
</footer>
