<?php
if (!isset($user_id)) {
    $user_id = $_COOKIE['user_id'] ?? '';
}

$profileLink = $user_id !== ''
    ? '<a href="patient/dashboard.php" class="btn outline">Patient Dashboard</a>'
    : '<a href="login.php" class="btn outline">Sign In</a>';

echo <<<HTML
<div class="header">
    <section class="flex">
        <a class="logo" href="home.php">
            <img src="components/image/cliniccare.png" width="140" alt="ClinicCare">
        </a>
        <nav class="navbar">
            <a href="home.php">Home</a>
            <a href="about.php">About</a>
            <a class="btn" href="login.php">Login</a>
        </nav>
        <div class="profile">
            $profileLink
        </div>
    </section>
</div>

<script src="js/user_script.js"></script>
HTML;
?>
