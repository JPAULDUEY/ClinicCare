<?php
// Clear the doctor cookie
setcookie('doctor_id', '', time() - 3600, '/');

// Redirect to login page
header('Location: ../doctor/login.php');
exit;
?>

-- Run this in phpMyAdmin to hash existing passwords
UPDATE doctors SET password = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi' WHERE email = 'janpol@gmail.com';
-- This hashes the password "12345678"
