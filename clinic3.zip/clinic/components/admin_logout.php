<?php

setcookie('admin_id', '', time() - 3600, '/');

header('Location: ../contact.php');
exit;
