<header>
	<div class="logo">
		<img src="/components/image/cliniccare.png" width="130">
	</div>
	<div class="right">
		<div class="bx bxs-user" id="user-btn" aria-label="Profile menu" role="button" tabindex="0"></div>
		<div class="toggle-btn"><i class="bx bx-menu"></i></div>
	</div>
	<div class="profile-detail" aria-hidden="true">
		<?php 
			$select_profile = $conn->prepare("SELECT * FROM `admin` WHERE id = ?");
			$select_profile->execute([$admin_id]);

			if ($select_profile->rowCount() > 0) {
				$fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);

		?>
		<div class="profile">
			<img src="../uploaded_files/<?= htmlspecialchars($fetch_profile['image'], ENT_QUOTES, 'UTF-8'); ?>" class="logo-img" alt="Admin avatar">
			<p><?= htmlspecialchars($fetch_profile['name'], ENT_QUOTES, 'UTF-8'); ?></p>
		</div>
		<div class="profile-actions">
			<a href="users.php" class="profile-action"><i class='bx bx-user-circle'></i><span>Patient Information</span></a>
			<a href="update.php" class="profile-action"><i class='bx bx-edit'></i><span>Update Profile</span></a>
			<a href="../components/admin_logout.php" class="profile-action logout"><i class='bx bx-log-out'></i><span>Logout</span></a>
		</div>
		<?php 
			}
		?>
	</div>
</header>
<div class="sidebar">
	<?php 
		$select_profile = $conn->prepare("SELECT * FROM `admin` WHERE id = ?");
		$select_profile->execute([$admin_id]);

		if ($select_profile->rowCount() > 0) {
			$fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);

	?>
	<div class="profile">
		<img src="../uploaded_files/<?= $fetch_profile['image']; ?>" class="logo-img">
		<p><?= $fetch_profile['name']; ?></p>
	</div>
	<?php 
		}
	?>
	<h5>menu</h5>
	<div class="navbar">
		<ul>
			<li><a href="dashboard.php"><i class="bx bxs-home-smile"></i>dashboard</a></li>
			<li><a href="users.php"><i class="bx bxs-user-detail"></i>patients</a></li>
			<li><a href="doctors.php"><i class="bx bxs-user-voice"></i>doctors</a></li>
			<li><a href="view_service.php"><i class="bx bxs-food-menu"></i>services</a></li>
			<li><a href="add_service.php"><i class="bx bxs-shopping-bags"></i>add service</a></li>
			<li><a href="../components/admin_logout.php"><i class="bx bx-log-out"></i>logout</a></li>
		</ul>
	</div>
</div>