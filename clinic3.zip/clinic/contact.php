<?php
    include 'components/connect.php';

    if (isset($_COOKIE['user_id'])) {
        $user_id = $_COOKIE['user_id'];
    } else {
        $user_id = '';
    }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ClinicCare | Login Options</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="css/auth_style.css?v=<?php echo time(); ?>">
</head>
<body class="portal-page">
    <div class="portal-layout">
        <header class="portal-nav">
            <a class="back-home-link" href="home.php">
                <i class='bx bx-chevron-left'></i>
                <span>Back to Home</span>
            </a>
        </header>

        <div class="portal-wrapper">
            <h1>Choose Your Portal</h1>
            <p>Select the profile that matches your role to continue to the secure login page.</p>
            <div class="portal-grid">
                <a class="portal-card patient" href="patient/login.php">
                    <div class="portal-icon"><i class='bx bx-user'></i></div>
                    <h2>Patients</h2>
                    <p>Book appointments, view prescriptions, and manage your health records.</p>
                </a>
                <a class="portal-card doctor" href="doctor/login.php">
                    <div class="portal-icon"><i class='bx bx-stethoscope'></i></div>
                    <h2>Doctors</h2>
                    <p>Review schedules, update patient notes, and collaborate with the care team.</p>
                </a>
                <a class="portal-card admin" href="admin/login.php">
                    <div class="portal-icon"><i class='bx bx-shield-quarter'></i></div>
                    <h2>Admins</h2>
                    <p>Oversee clinic operations, manage services, and monitor system activity.</p>
                </a>
            </div>
            <div class="portal-register-link">Don't have a patient account? <a href="patient/register.php">Register here</a></div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
    <?php include 'components/alert.php'; ?>
</body>
</html>
