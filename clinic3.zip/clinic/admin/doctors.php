<?php
    include '../components/connect.php';
    require_once __DIR__ . '/admin_helpers.php';

    if (isset($_COOKIE['admin_id'])) {
        $admin_id = $_COOKIE['admin_id'];
    } else {
        $admin_id = '';
        header('location:login.php');
        exit;
    }

    $currentPage = basename($_SERVER['PHP_SELF']);

    $formValues = [
        'specialization' => '',
        'name' => '',
        'clinic_address' => '',
        'contact_number' => '',
        'email' => ''
    ];

    $doctorColumns = fetchTableColumns($conn, 'doctors');

    $nameColumn = firstAvailableColumn($doctorColumns, ['name', 'full_name', 'fullname']);
    $emailColumn = firstAvailableColumn($doctorColumns, ['email', 'email_address']);
    $specializationColumn = firstAvailableColumn($doctorColumns, ['specialization', 'speciality', 'specialty', 'department']);
    $addressColumn = firstAvailableColumn($doctorColumns, ['clinic_address', 'address', 'location']);
    $contactColumn = firstAvailableColumn($doctorColumns, ['contact_number', 'phone', 'mobile', 'phone_number']);
    $passwordColumn = firstAvailableColumn($doctorColumns, ['password', 'pass', 'hashed_password']);
    $createdAtColumn = firstAvailableColumn($doctorColumns, ['created_at', 'registered_at', 'added_on', 'createdOn']);

    $doctorCreationAllowed = $nameColumn !== null && $emailColumn !== null;

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_doctor'])) {
        $formValues['specialization'] = trim(filter_var($_POST['specialization'] ?? '', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
        $formValues['name'] = trim(filter_var($_POST['name'] ?? '', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
        $formValues['clinic_address'] = trim(filter_var($_POST['clinic_address'] ?? '', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
        $formValues['contact_number'] = trim(filter_var($_POST['contact_number'] ?? '', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
        $formValues['email'] = trim(filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL));

        if (!$doctorCreationAllowed) {
            $error_msg[] = 'Doctor table is missing required columns. Please contact support.';
        } elseif ($formValues['name'] === '' || $formValues['email'] === '') {
            $warning_msg[] = 'Name and email are required.';
        } else {
            $duplicateFound = false;

            if ($emailColumn !== null) {
                try {
                    $duplicateCheck = $conn->prepare("SELECT COUNT(*) FROM `doctors` WHERE `$emailColumn` = ? LIMIT 1");
                    $duplicateCheck->execute([$formValues['email']]);
                    $duplicateFound = (int) $duplicateCheck->fetchColumn() > 0;
                } catch (Exception $e) {
                    // Ignore duplicate check errors and proceed with insert attempt.
                }
            }

            if ($duplicateFound) {
                $warning_msg[] = 'A doctor with that email already exists.';
            } else {
                $columnsToInsert = [];
                $valuesToInsert = [];

                $columnsToInsert[$nameColumn] = $formValues['name'];
                $valuesToInsert[] = $formValues['name'];

                $columnsToInsert[$emailColumn] = $formValues['email'];
                $valuesToInsert[] = $formValues['email'];

                if ($specializationColumn !== null && $formValues['specialization'] !== '') {
                    $columnsToInsert[$specializationColumn] = $formValues['specialization'];
                    $valuesToInsert[] = $formValues['specialization'];
                }

                if ($addressColumn !== null && $formValues['clinic_address'] !== '') {
                    $columnsToInsert[$addressColumn] = $formValues['clinic_address'];
                    $valuesToInsert[] = $formValues['clinic_address'];
                }

                if ($contactColumn !== null && $formValues['contact_number'] !== '') {
                    $columnsToInsert[$contactColumn] = $formValues['contact_number'];
                    $valuesToInsert[] = $formValues['contact_number'];
                }

                $tempPasswordPlain = null;

                if ($passwordColumn !== null) {
                    $tempPasswordPlain = generateTempPassword();
                    $hashedPassword = sha1($tempPasswordPlain);
                    $columnsToInsert[$passwordColumn] = $hashedPassword;
                    $valuesToInsert[] = $hashedPassword;
                }

                if ($createdAtColumn !== null) {
                    $currentTimestamp = date('Y-m-d H:i:s');
                    $columnsToInsert[$createdAtColumn] = $currentTimestamp;
                    $valuesToInsert[] = $currentTimestamp;
                }

                try {
                    $columnList = array_map(static function ($column) {
                        return "`$column`";
                    }, array_keys($columnsToInsert));

                    $placeholders = rtrim(str_repeat('?,', count($valuesToInsert)), ',');

                    $insertSql = 'INSERT INTO `doctors` (' . implode(',', $columnList) . ') VALUES (' . $placeholders . ')';
                    $insertStmt = $conn->prepare($insertSql);
                    $insertStmt->execute($valuesToInsert);

                    $success_msg[] = 'Doctor profile added successfully.';

                    if ($tempPasswordPlain !== null) {
                        $info_msg[] = 'Temporary password: ' . $tempPasswordPlain;
                    }

                    $formValues = [
                        'specialization' => '',
                        'name' => '',
                        'clinic_address' => '',
                        'contact_number' => '',
                        'email' => ''
                    ];
                } catch (Exception $e) {
                    $error_msg[] = 'Failed to add doctor. Please try again.';
                }
            }
        }
    }

    $searchQuery = trim(filter_var($_GET['search'] ?? '', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
    $doctorDirectory = [];
    $doctorDirectoryError = false;

    try {
        $selectSql = 'SELECT * FROM `doctors`';
        $selectParams = [];

        $searchConditions = [];

        if ($searchQuery !== '') {
            if ($nameColumn !== null) {
                $searchConditions[] = "`$nameColumn` LIKE ?";
                $selectParams[] = '%' . $searchQuery . '%';
            }

            if ($emailColumn !== null) {
                $searchConditions[] = "`$emailColumn` LIKE ?";
                $selectParams[] = '%' . $searchQuery . '%';
            }

            if ($specializationColumn !== null) {
                $searchConditions[] = "`$specializationColumn` LIKE ?";
                $selectParams[] = '%' . $searchQuery . '%';
            }
        }

        if (!empty($searchConditions)) {
            $selectSql .= ' WHERE ' . implode(' OR ', $searchConditions);
        }

        if ($createdAtColumn !== null) {
            $selectSql .= " ORDER BY `$createdAtColumn` DESC";
        } elseif (in_array('id', $doctorColumns, true)) {
            $selectSql .= ' ORDER BY `id` DESC';
        }

        $selectStmt = $conn->prepare($selectSql);
        $selectStmt->execute($selectParams);
        $doctorDirectory = $selectStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Exception $e) {
        $doctorDirectory = [];
        $doctorDirectoryError = true;
    }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ClinicCare | Manage Doctors</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="../css/admin_style.css?v=<?php echo time(); ?>">
</head>
<body>

<?php include '../components/admin_header.php'; ?>

<main class="admin-dashboard-wrapper">
    <div class="admin-dashboard-shell">
        <aside class="admin-template-nav">
            <div class="template-logo">
                <span class="template-logo__brand">Clinic</span>
                <button class="template-logo__toggle" type="button" aria-label="Toggle navigation">
                    <i class='bx bx-menu'></i>
                </button>
            </div>
            <nav class="template-nav-list">
                <a href="dashboard.php" class="template-nav-item<?= $currentPage === 'dashboard.php' ? ' active' : ''; ?>"><i class='bx bxs-dashboard'></i><span>Dashboard</span></a>
                <a href="users.php" class="template-nav-item<?= $currentPage === 'users.php' ? ' active' : ''; ?>"><i class='bx bxs-user-account'></i><span>Users</span></a>
                <a href="doctors.php" class="template-nav-item<?= $currentPage === 'doctors.php' ? ' active' : ''; ?>"><i class='bx bxs-user-voice'></i><span>Doctors</span></a>
                <a href="services.php" class="template-nav-item<?= $currentPage === 'services.php' ? ' active' : ''; ?>"><i class='bx bx-list-ul'></i><span>Services</span></a>
                <a href="add_service.php" class="template-nav-item<?= $currentPage === 'add_service.php' ? ' active' : ''; ?>"><i class='bx bx-plus-circle'></i><span>Add Service</span></a>
                <a href="../components/admin_logout.php" class="template-nav-item"><i class='bx bx-log-out'></i><span>Logout</span></a>
            </nav>
        </aside>

        <section class="admin-doctor-content">
            <div class="dashboard-header">
                <div class="dashboard-headings">
                    <p class="breadcrumb">Admin / Doctors</p>
                    <h1>Admin | Doctors</h1>
                    <span>Add doctors and manage their profiles from the directory.</span>
                </div>
            </div>

            <div class="doctor-management-grid">
                <div class="doctor-form-card">
                    <h2>Add Doctor</h2>
                    <form method="post" action="" class="doctor-form">
                        <div class="form-field">
                            <label for="specialization">Doctor Specialization</label>
                            <input type="text" id="specialization" name="specialization" placeholder="e.g., Cardiologist" maxlength="120" value="<?= htmlspecialchars($formValues['specialization'], ENT_QUOTES, 'UTF-8'); ?>">
                        </div>
                        <div class="form-field">
                            <label for="name">Doctor Name</label>
                            <input type="text" id="name" name="name" placeholder="Doctor's full name" maxlength="120" value="<?= htmlspecialchars($formValues['name'], ENT_QUOTES, 'UTF-8'); ?>" required>
                        </div>
                        <div class="form-field">
                            <label for="clinic_address">Clinic Address</label>
                            <input type="text" id="clinic_address" name="clinic_address" placeholder="Clinic or hospital address" maxlength="160" value="<?= htmlspecialchars($formValues['clinic_address'], ENT_QUOTES, 'UTF-8'); ?>">
                        </div>
                        <div class="form-field">
                            <label for="contact_number">Contact Number</label>
                            <input type="text" id="contact_number" name="contact_number" placeholder="Contact phone" maxlength="30" value="<?= htmlspecialchars($formValues['contact_number'], ENT_QUOTES, 'UTF-8'); ?>">
                        </div>
                        <div class="form-field">
                            <label for="email">Doctor Email</label>
                            <input type="email" id="email" name="email" placeholder="name@example.com" maxlength="150" value="<?= htmlspecialchars($formValues['email'], ENT_QUOTES, 'UTF-8'); ?>" required>
                        </div>
                        <button type="submit" name="add_doctor" class="primary-action">Save Doctor</button>
                        <?php if ($passwordColumn === null): ?>
                            <p class="helper-text">Note: The doctors table does not have a password column. Please ensure login credentials are handled separately.</p>
                        <?php endif; ?>
                    </form>
                </div>

                <div class="doctor-directory-card">
                    <div class="card-header">
                        <div>
                            <h2>Doctor Directory</h2>
                            <span>Review each doctor's information and specialization.</span>
                        </div>
                        <form method="get" action="" class="doctor-search">
                            <input type="text" name="search" placeholder="Search doctors..." value="<?= htmlspecialchars($searchQuery, ENT_QUOTES, 'UTF-8'); ?>">
                            <button type="submit" aria-label="Search">
                                <i class='bx bx-search'></i>
                            </button>
                        </form>
                    </div>

                    <div class="doctor-list">
                        <?php if ($doctorDirectoryError): ?>
                            <p class="doctor-empty">Failed to load doctors. Please refresh the page.</p>
                        <?php elseif (empty($doctorDirectory)): ?>
                            <p class="doctor-empty">No doctors found for the current filters.</p>
                        <?php else: ?>
                            <?php foreach ($doctorDirectory as $doctor): ?>
                                <?php
                                    $doctorName = extractField($doctor, [$nameColumn, 'name', 'full_name', 'fullname']) ?? 'Unnamed Doctor';
                                    $doctorEmail = extractField($doctor, [$emailColumn, 'email']);
                                    $doctorSpecialization = extractField($doctor, [$specializationColumn, 'specialization', 'speciality', 'specialty']);
                                    $doctorContact = extractField($doctor, [$contactColumn, 'contact_number', 'phone', 'mobile']);
                                    $doctorAddress = extractField($doctor, [$addressColumn, 'clinic_address', 'address']);
                                    $doctorCreated = extractField($doctor, [$createdAtColumn, 'created_at', 'registered_at', 'added_on']);
                                ?>
                                <article class="doctor-card">
                                    <div class="doctor-card-header">
                                        <h3><?= htmlspecialchars($doctorName, ENT_QUOTES, 'UTF-8'); ?></h3>
                                        <?php if ($doctorSpecialization): ?>
                                            <span class="doctor-badge"><?= htmlspecialchars($doctorSpecialization, ENT_QUOTES, 'UTF-8'); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    <?php if ($doctorEmail): ?>
                                        <p><i class='bx bx-envelope'></i><?= htmlspecialchars($doctorEmail, ENT_QUOTES, 'UTF-8'); ?></p>
                                    <?php endif; ?>
                                    <?php if ($doctorContact): ?>
                                        <p><i class='bx bx-phone'></i><?= htmlspecialchars($doctorContact, ENT_QUOTES, 'UTF-8'); ?></p>
                                    <?php endif; ?>
                                    <?php if ($doctorAddress): ?>
                                        <p><i class='bx bx-map'></i><?= htmlspecialchars($doctorAddress, ENT_QUOTES, 'UTF-8'); ?></p>
                                    <?php endif; ?>
                                    <?php if ($doctorCreated): ?>
                                        <p class="doctor-meta"><i class='bx bx-time-five'></i>Added: <?= htmlspecialchars(formatDateDisplay($doctorCreated), ENT_QUOTES, 'UTF-8'); ?></p>
                                    <?php endif; ?>
                                </article>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
    </div>
</main>

<!----sweetalert cdn link----->
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
<!-----------custom js link------------->
<script type="text/javascript" src="../js/admin_script.js"></script>
<?php include '../components/alert.php'; ?>
<?php include '../components/admin_footer.php'; ?>
</body>
</html>
