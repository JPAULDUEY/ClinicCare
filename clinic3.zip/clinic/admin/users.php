<?php
    include '../components/connect.php';
    require_once __DIR__ . '/admin_helpers.php';

    if (isset($_COOKIE['admin_id'])) {
        $admin_id = $_COOKIE['admin_id'];
    } else {
        $admin_id = '';
        header('location:login.php');
        exit;
    }

    $currentPage = basename($_SERVER['PHP_SELF']);

    $patientColumns = fetchTableColumns($conn, 'patients');
    $patientIdColumn = firstAvailableColumn($patientColumns, ['id', 'patient_id', 'patientID']);
    $patientNameColumn = firstAvailableColumn($patientColumns, ['name', 'full_name', 'fullname']);
    $patientEmailColumn = firstAvailableColumn($patientColumns, ['email', 'email_address']);
    $patientContactColumn = firstAvailableColumn($patientColumns, ['contact_number', 'phone', 'mobile', 'phone_number']);
    $patientCreatedColumn = firstAvailableColumn($patientColumns, ['created_at', 'registered_at', 'joined_at', 'createdOn']);

    $appointmentColumns = fetchTableColumns($conn, 'appointments');
    $appointmentPatientColumn = firstAvailableColumn($appointmentColumns, ['patient_id', 'patientID', 'patient', 'patient_name']);
    $appointmentStatusColumn = firstAvailableColumn($appointmentColumns, ['status', 'appointment_status', 'current_status', 'state']);
    $appointmentDateColumn = firstAvailableColumn($appointmentColumns, ['appointment_date', 'schedule_date', 'visit_date', 'created_at', 'updated_at', 'booked_on', 'date']);
    $appointmentOrderColumn = firstAvailableColumn($appointmentColumns, ['updated_at', 'created_at', 'appointment_date', 'schedule_date', 'visit_date', 'id', 'appointment_id']);

    $searchQuery = trim(filter_var($_GET['search'] ?? '', FILTER_SANITIZE_FULL_SPECIAL_CHARS));

    $patients = [];

    if (!empty($patientColumns)) {
        try {
            $patientSql = 'SELECT * FROM `patients`';
            $patientParams = [];
            $searchConditions = [];

            if ($searchQuery !== '') {
                if ($patientNameColumn !== null) {
                    $searchConditions[] = "`$patientNameColumn` LIKE ?";
                    $patientParams[] = '%' . $searchQuery . '%';
                }

                if ($patientEmailColumn !== null) {
                    $searchConditions[] = "`$patientEmailColumn` LIKE ?";
                    $patientParams[] = '%' . $searchQuery . '%';
                }
            }

            if (!empty($searchConditions)) {
                $patientSql .= ' WHERE ' . implode(' OR ', $searchConditions);
            }

            if ($patientCreatedColumn !== null) {
                $patientSql .= " ORDER BY `$patientCreatedColumn` DESC";
            } elseif ($patientIdColumn !== null) {
                $patientSql .= " ORDER BY `$patientIdColumn` DESC";
            }

            $patientStmt = $conn->prepare($patientSql);
            $patientStmt->execute($patientParams);
            $patients = $patientStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Exception $e) {
            $patients = [];
        }
    }

    $statusByPatient = [];

    if ($appointmentPatientColumn !== null && $appointmentStatusColumn !== null) {
        try {
            $selectFields = [
                "`$appointmentPatientColumn` AS patient_key",
                "$appointmentStatusColumn AS status_value"
            ];

            if ($appointmentDateColumn !== null) {
                $selectFields[] = "`$appointmentDateColumn` AS status_time";
            } else {
                $selectFields[] = "NULL AS status_time";
            }

            if ($appointmentOrderColumn !== null) {
                $selectFields[] = "`$appointmentOrderColumn` AS order_value";
            } else {
                $selectFields[] = "NULL AS order_value";
            }

            $statusSql = 'SELECT ' . implode(', ', $selectFields) . ' FROM `appointments` WHERE `' . $appointmentPatientColumn . '` IS NOT NULL';

            $orderParts = [];
            if ($appointmentDateColumn !== null) {
                $orderParts[] = "`$appointmentDateColumn` DESC";
            }
            if ($appointmentOrderColumn !== null && $appointmentOrderColumn !== $appointmentDateColumn) {
                $orderParts[] = "`$appointmentOrderColumn` DESC";
            }
            if (empty($orderParts)) {
                $orderParts[] = '`' . $appointmentPatientColumn . '` DESC';
            }

            $statusSql .= ' ORDER BY ' . implode(', ', $orderParts);

            $statusStmt = $conn->prepare($statusSql);
            $statusStmt->execute();

            while ($row = $statusStmt->fetch(PDO::FETCH_ASSOC)) {
                $patientKey = isset($row['patient_key']) ? trim((string) $row['patient_key']) : '';
                if ($patientKey === '') {
                    continue;
                }

                if (!array_key_exists($patientKey, $statusByPatient)) {
                    $statusByPatient[$patientKey] = [
                        'status' => $row['status_value'] ?? null,
                        'time' => $row['status_time'] ?? ($row['order_value'] ?? null)
                    ];
                }
            }
        } catch (Exception $e) {
            $statusByPatient = [];
        }
    }

    $patientRows = [];
    $completeCount = 0;
    $pendingCount = 0;

    foreach ($patients as $patient) {
        $patientKey = null;

        if ($patientIdColumn !== null && array_key_exists($patientIdColumn, $patient)) {
            $patientKey = trim((string) $patient[$patientIdColumn]);
        } elseif ($patientNameColumn !== null && array_key_exists($patientNameColumn, $patient)) {
            $patientKey = trim((string) $patient[$patientNameColumn]);
        }

        $statusInfo = $patientKey !== null && isset($statusByPatient[$patientKey]) ? $statusByPatient[$patientKey] : null;
        $rawStatus = $statusInfo['status'] ?? null;

        $normalizedStatus = strtolower(trim((string) ($rawStatus ?? '')));
        $transactionState = 'pending';
        $displayStatus = 'Pending Transaction';
        $statusBadge = 'pending';
        $statusDetail = 'No action yet';

        if ($rawStatus !== null && $normalizedStatus !== '') {
            if (
                strpos($normalizedStatus, 'complete') !== false ||
                strpos($normalizedStatus, 'completed') !== false ||
                strpos($normalizedStatus, 'done') !== false ||
                strpos($normalizedStatus, 'finished') !== false ||
                strpos($normalizedStatus, 'resolved') !== false
            ) {
                $transactionState = 'complete';
                $displayStatus = 'Complete Transaction';
                $statusBadge = 'complete';
                $statusDetail = formatStatus($rawStatus);
            } else {
                $transactionState = 'pending';
                $displayStatus = 'Pending Transaction';
                $statusBadge = 'pending';
                $statusDetail = formatStatus($rawStatus);
            }
        }

        if ($transactionState === 'complete') {
            $completeCount++;
        } else {
            $pendingCount++;
        }

        $patientNameValue = ($patientNameColumn !== null && array_key_exists($patientNameColumn, $patient)) ? $patient[$patientNameColumn] : null;
        $patientEmailValue = ($patientEmailColumn !== null && array_key_exists($patientEmailColumn, $patient)) ? $patient[$patientEmailColumn] : null;
        $patientContactValue = ($patientContactColumn !== null && array_key_exists($patientContactColumn, $patient)) ? $patient[$patientContactColumn] : null;
        $patientJoinedValue = ($patientCreatedColumn !== null && array_key_exists($patientCreatedColumn, $patient)) ? $patient[$patientCreatedColumn] : null;

        $patientRows[] = [
            'name' => mapValueWithFallback($patientNameValue, []),
            'email' => mapValueWithFallback($patientEmailValue, []),
            'contact' => mapValueWithFallback($patientContactValue, []),
            'joined' => $patientJoinedValue !== null ? formatDateDisplay($patientJoinedValue) : '—',
            'status_label' => $displayStatus,
            'status_detail' => $statusDetail,
            'status_class' => $statusBadge,
            'last_update' => isset($statusInfo['time']) ? formatDateDisplay($statusInfo['time']) : '—'
        ];
    }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ClinicCare | Patients</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="../css/admin_style.css?v=<?php echo time(); ?>">
</head>
<body>

<?php include '../components/admin_header.php'; ?>

<main class="admin-dashboard-wrapper">
    <div class="admin-dashboard-shell">
        <aside class="admin-template-nav">
            <div class="template-logo">
                <span class="template-logo__brand">Clinic</span>
                <button class="template-logo__toggle" type="button" aria-label="Toggle navigation">
                    <i class='bx bx-menu'></i>
                </button>
            </div>
            <nav class="template-nav-list">
                <a href="dashboard.php" class="template-nav-item<?= $currentPage === 'dashboard.php' ? ' active' : ''; ?>"><i class='bx bxs-dashboard'></i><span>Dashboard</span></a>
                <a href="users.php" class="template-nav-item<?= $currentPage === 'users.php' ? ' active' : ''; ?>"><i class='bx bxs-user-account'></i><span>Users</span></a>
                <a href="doctors.php" class="template-nav-item<?= $currentPage === 'doctors.php' ? ' active' : ''; ?>"><i class='bx bxs-user-voice'></i><span>Doctors</span></a>
                <a href="view_service.php" class="template-nav-item<?= $currentPage === 'view_service.php' ? ' active' : ''; ?>"><i class='bx bx-list-ul'></i><span>Services</span></a>
                <a href="add_service.php" class="template-nav-item<?= $currentPage === 'add_service.php' ? ' active' : ''; ?>"><i class='bx bx-plus-circle'></i><span>Add Service</span></a>
                <a href="../components/admin_logout.php" class="template-nav-item"><i class='bx bx-log-out'></i><span>Logout</span></a>
            </nav>
        </aside>

        <section class="admin-users-content">
            <div class="dashboard-header">
                <div class="dashboard-headings">
                    <p class="breadcrumb">Admin / Users</p>
                    <h1>Admin | Patients</h1>
                    <span>Review all registered patients and monitor transaction progress.</span>
                </div>
            </div>

            <div class="user-summary-grid">
                <div class="user-summary-card complete">
                    <p class="summary-label">Complete Transactions</p>
                    <p class="summary-value"><?= number_format($completeCount); ?></p>
                </div>
                <div class="user-summary-card pending">
                    <p class="summary-label">Pending Transactions</p>
                    <p class="summary-value"><?= number_format($pendingCount); ?></p>
                </div>
            </div>

            <div class="user-table-card">
                <div class="card-header">
                    <div>
                        <h2>Patient Directory</h2>
                        <span>Statuses update automatically based on the latest appointment record.</span>
                    </div>
                    <form method="get" action="" class="doctor-search user-search">
                        <input type="text" name="search" placeholder="Search patients..." value="<?= htmlspecialchars($searchQuery, ENT_QUOTES, 'UTF-8'); ?>">
                        <button type="submit" aria-label="Search">
                            <i class='bx bx-search'></i>
                        </button>
                    </form>
                </div>

                <div class="table-wrapper">
                    <?php if (empty($patientRows)): ?>
                        <p class="empty-table">No patients found.</p>
                    <?php else: ?>
                        <table class="user-table">
                            <thead>
                                <tr>
                                    <th>Patient Name</th>
                                    <th>Email</th>
                                    <th>Contact</th>
                                    <th>Last Transaction</th>
                                    <th>Status</th>
                                    <th>Updated</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($patientRows as $row): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><?= htmlspecialchars($row['email'], ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><?= htmlspecialchars($row['contact'], ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><?= htmlspecialchars($row['status_detail'], ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><span class="transaction-chip <?= htmlspecialchars($row['status_class'], ENT_QUOTES, 'UTF-8'); ?>"><?= htmlspecialchars($row['status_label'], ENT_QUOTES, 'UTF-8'); ?></span></td>
                                        <td><?= htmlspecialchars($row['last_update'], ENT_QUOTES, 'UTF-8'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>
</main>

<!----sweetalert cdn link----->
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
<!-----------custom js link------------->
<script type="text/javascript" src="../js/admin_script.js"></script>
<?php include '../components/alert.php'; ?>
<?php include '../components/admin_footer.php'; ?>
</body>
</html>
