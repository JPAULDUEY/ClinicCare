<?php
    include '../components/connect.php';
    require_once __DIR__ . '/admin_helpers.php';

    if (isset($_COOKIE['admin_id'])) {
        $admin_id = $_COOKIE['admin_id'];
    } else {
        $admin_id = '';
        header('location:login.php');
        exit;
    }

    $currentPage = basename($_SERVER['PHP_SELF']);

    $serviceColumns = fetchTableColumns($conn, 'services');

    $serviceIdColumn = firstAvailableColumn($serviceColumns, ['id', 'service_id']);
    $serviceNameColumn = firstAvailableColumn($serviceColumns, ['name', 'service_name', 'title']);
    $servicePriceColumn = firstAvailableColumn($serviceColumns, ['price', 'cost', 'amount']);
    $serviceDepartmentColumn = firstAvailableColumn($serviceColumns, ['department', 'category', 'type']);
    $serviceStatusColumn = firstAvailableColumn($serviceColumns, ['status', 'state']);
    $serviceDescriptionColumn = firstAvailableColumn($serviceColumns, ['service_detail', 'description', 'details']);
    $serviceImageColumn = firstAvailableColumn($serviceColumns, ['image', 'thumbnail', 'photo']);
    $serviceUpdatedColumn = firstAvailableColumn($serviceColumns, ['updated_at', 'modified_at', 'created_at', 'createdOn']);

    $searchQuery = trim(filter_var($_GET['search'] ?? '', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
    $statusFilter = trim(filter_var($_GET['status'] ?? '', FILTER_SANITIZE_FULL_SPECIAL_CHARS));

    $services = [];

    if (!empty($serviceColumns)) {
        try {
            $sql = 'SELECT * FROM `services`';
            $params = [];
            $conditions = [];

            if ($searchQuery !== '') {
                $searchParts = [];

                if ($serviceNameColumn !== null) {
                    $searchParts[] = "`$serviceNameColumn` LIKE ?";
                    $params[] = '%' . $searchQuery . '%';
                }

                if ($serviceDepartmentColumn !== null) {
                    $searchParts[] = "`$serviceDepartmentColumn` LIKE ?";
                    $params[] = '%' . $searchQuery . '%';
                }

                if (!empty($searchParts)) {
                    $conditions[] = '(' . implode(' OR ', $searchParts) . ')';
                }
            }

            if ($statusFilter !== '' && $serviceStatusColumn !== null) {
                $conditions[] = "`$serviceStatusColumn` = ?";
                $params[] = $statusFilter;
            }

            if (!empty($conditions)) {
                $sql .= ' WHERE ' . implode(' AND ', $conditions);
            }

            if ($serviceUpdatedColumn !== null) {
                $sql .= " ORDER BY `$serviceUpdatedColumn` DESC";
            } elseif ($serviceIdColumn !== null) {
                $sql .= " ORDER BY `$serviceIdColumn` DESC";
            }

            $stmt = $conn->prepare($sql);
            $stmt->execute($params);
            $services = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Exception $e) {
            $services = [];
        }
    }

    if (isset($_GET['delete']) && $serviceIdColumn !== null) {
        $deleteId = trim($_GET['delete']);

        if ($deleteId !== '') {
            try {
                $deleteStmt = $conn->prepare("DELETE FROM `services` WHERE `$serviceIdColumn` = ? LIMIT 1");
                $deleteStmt->execute([$deleteId]);
                $success_msg[] = 'Service removed successfully.';
                header('location:view_service.php');
                exit;
            } catch (Exception $e) {
                $error_msg[] = 'Failed to delete service. Please try again.';
            }
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ClinicCare | Services</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="../css/admin_style.css?v=<?php echo time(); ?>">
</head>
<body>

<?php include '../components/admin_header.php'; ?>

<main class="admin-dashboard-wrapper">
    <div class="admin-dashboard-shell">
        <aside class="admin-template-nav">
            <div class="template-logo">
                <span class="template-logo__brand">Clinic</span>
                <button class="template-logo__toggle" type="button" aria-label="Toggle navigation">
                    <i class='bx bx-menu'></i>
                </button>
            </div>
            <nav class="template-nav-list">
                <a href="dashboard.php" class="template-nav-item<?= $currentPage === 'dashboard.php' ? ' active' : ''; ?>"><i class='bx bxs-dashboard'></i><span>Dashboard</span></a>
                <a href="users.php" class="template-nav-item<?= $currentPage === 'users.php' ? ' active' : ''; ?>"><i class='bx bxs-user-account'></i><span>Users</span></a>
                <a href="doctors.php" class="template-nav-item<?= $currentPage === 'doctors.php' ? ' active' : ''; ?>"><i class='bx bxs-user-voice'></i><span>Doctors</span></a>
                <a href="view_service.php" class="template-nav-item<?= $currentPage === 'view_service.php' ? ' active' : ''; ?>"><i class='bx bx-list-ul'></i><span>Services</span></a>
                <a href="add_service.php" class="template-nav-item<?= $currentPage === 'add_service.php' ? ' active' : ''; ?>"><i class='bx bx-plus-circle'></i><span>Add Service</span></a>
                <a href="../components/admin_logout.php" class="template-nav-item"><i class='bx bx-log-out'></i><span>Logout</span></a>
            </nav>
        </aside>

        <section class="admin-services-content">
            <div class="dashboard-header">
                <div class="dashboard-headings">
                    <p class="breadcrumb">Admin / Services</p>
                    <h1>Admin | Services</h1>
                    <span>Manage the catalog of clinical services and keep details up to date.</span>
                </div>
                <a class="dashboard-user__action" href="add_service.php">Add New Service</a>
            </div>

            <div class="service-toolbar">
                <form method="get" action="" class="service-filters">
                    <div class="search-field">
                        <i class='bx bx-search'></i>
                        <input type="text" name="search" placeholder="Search by name or department" value="<?= htmlspecialchars($searchQuery, ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="status-field">
                        <label for="status">Status</label>
                        <select id="status" name="status">
                            <option value="">All</option>
                            <option value="active" <?= $statusFilter === 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="deactive" <?= $statusFilter === 'deactive' ? 'selected' : ''; ?>>Draft</option>
                        </select>
                    </div>
                    <button type="submit" class="btn-filter">Apply</button>
                </form>
            </div>

            <div class="service-table-card">
                <div class="table-wrapper">
                    <?php if (empty($services)): ?>
                        <p class="empty-table">No services found.</p>
                    <?php else: ?>
                        <table class="service-table">
                            <thead>
                                <tr>
                                    <th>Service</th>
                                    <th>Department</th>
                                    <th>Price</th>
                                    <th>Status</th>
                                    <th>Updated</th>
                                    <th class="actions-col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($services as $service): ?>
                                    <?php
                                        $serviceId = $serviceIdColumn !== null && array_key_exists($serviceIdColumn, $service) ? $service[$serviceIdColumn] : '';
                                        $serviceName = $serviceNameColumn !== null && array_key_exists($serviceNameColumn, $service) ? $service[$serviceNameColumn] : 'Untitled';
                                        $serviceDepartment = $serviceDepartmentColumn !== null && array_key_exists($serviceDepartmentColumn, $service) ? $service[$serviceDepartmentColumn] : '—';
                                        $servicePrice = $servicePriceColumn !== null && array_key_exists($servicePriceColumn, $service) ? $service[$servicePriceColumn] : null;
                                        $serviceStatus = $serviceStatusColumn !== null && array_key_exists($serviceStatusColumn, $service) ? strtolower(trim((string) $service[$serviceStatusColumn])) : '';
                                        $serviceUpdated = $serviceUpdatedColumn !== null && array_key_exists($serviceUpdatedColumn, $service) ? formatDateDisplay($service[$serviceUpdatedColumn]) : '—';
                                        $serviceImage = $serviceImageColumn !== null && array_key_exists($serviceImageColumn, $service) ? $service[$serviceImageColumn] : '';
                                        $serviceDescription = $serviceDescriptionColumn !== null && array_key_exists($serviceDescriptionColumn, $service) ? $service[$serviceDescriptionColumn] : '';

                                        $statusClass = 'draft';
                                        $statusLabel = 'Draft';

                                        if ($serviceStatus === 'active') {
                                            $statusClass = 'active';
                                            $statusLabel = 'Active';
                                        } elseif ($serviceStatus === 'deactive') {
                                            $statusClass = 'draft';
                                            $statusLabel = 'Draft';
                                        } elseif ($serviceStatus !== '') {
                                            $statusClass = 'custom';
                                            $statusLabel = formatStatus($serviceStatus);
                                        }
                                    ?>
                                    <tr>
                                        <td>
                                            <div class="service-info">
                                                <?php if ($serviceImage): ?>
                                                    <img src="../uploaded_files/<?= htmlspecialchars($serviceImage, ENT_QUOTES, 'UTF-8'); ?>" alt="<?= htmlspecialchars($serviceName, ENT_QUOTES, 'UTF-8'); ?>">
                                                <?php else: ?>
                                                    <div class="service-placeholder"><i class='bx bx-image'></i></div>
                                                <?php endif; ?>
                                                <div>
                                                    <p class="service-name"><?= htmlspecialchars($serviceName, ENT_QUOTES, 'UTF-8'); ?></p>
                                                    <?php if ($serviceDescription): ?>
                                                        <p class="service-desc"><?= htmlspecialchars(mb_strimwidth($serviceDescription, 0, 120, '…', 'UTF-8'), ENT_QUOTES, 'UTF-8'); ?></p>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?= htmlspecialchars($serviceDepartment, ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><?= $servicePrice !== null ? '₱' . number_format((float) $servicePrice, 2) : '—'; ?></td>
                                        <td><span class="service-status <?= $statusClass; ?>"><?= htmlspecialchars($statusLabel, ENT_QUOTES, 'UTF-8'); ?></span></td>
                                        <td><?= htmlspecialchars($serviceUpdated, ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td class="actions-col">
                                            <div class="action-buttons">
                                                <a class="action-btn edit" href="add_service.php?edit=<?= urlencode($serviceId); ?>"><i class='bx bx-edit'></i>Edit</a>
                                                <a class="action-btn delete" href="view_service.php?delete=<?= urlencode($serviceId); ?>" onclick="return confirm('Delete this service?');"><i class='bx bx-trash'></i>Delete</a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>
</main>

<!----sweetalert cdn link----->
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
<!-----------custom js link------------->
<script type="text/javascript" src="../js/admin_script.js"></script>
<?php include '../components/alert.php'; ?>
<?php include '../components/admin_footer.php'; ?>
</body>
</html>
