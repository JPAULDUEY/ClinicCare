<?php

if (!function_exists('fetchTableColumns')) {
    function fetchTableColumns(PDO $conn, string $table): array
    {
        try {
            $stmt = $conn->prepare("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?");
            $stmt->execute([$table]);
            return $stmt->fetchAll(PDO::FETCH_COLUMN) ?: [];
        } catch (Exception $e) {
            return [];
        }
    }
}

if (!function_exists('firstAvailableColumn')) {
    function firstAvailableColumn(array $columns, array $candidates): ?string
    {
        foreach ($candidates as $candidate) {
            if ($candidate && in_array($candidate, $columns, true)) {
                return $candidate;
            }
        }

        return null;
    }
}

if (!function_exists('safeCount')) {
    function safeCount(PDO $conn, string $table): int
    {
        try {
            $stmt = $conn->query("SELECT COUNT(*) FROM `$table`");
            return (int) $stmt->fetchColumn();
        } catch (Exception $e) {
            return 0;
        }
    }
}

if (!function_exists('extractField')) {
    function extractField(array $row, array $candidates): ?string
    {
        foreach ($candidates as $candidate) {
            if (!$candidate) {
                continue;
            }

            if (array_key_exists($candidate, $row)) {
                $value = $row[$candidate];

                if ($value === null) {
                    continue;
                }

                if (is_string($value)) {
                    $value = trim($value);
                }

                if ($value === '' || $value === false) {
                    continue;
                }

                return (string) $value;
            }
        }

        return null;
    }
}

if (!function_exists('formatStatus')) {
    function formatStatus(?string $status): string
    {
        if ($status === null || $status === '') {
            return 'N/A';
        }

        $normalized = strtolower((string) $status);
        $normalized = str_replace(['_', '-'], ' ', $normalized);

        return ucwords($normalized);
    }
}

if (!function_exists('slugifyStatus')) {
    function slugifyStatus(?string $status): string
    {
        if ($status === null || $status === '') {
            return 'na';
        }

        $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', (string) $status));
        return trim($slug, '-') ?: 'na';
    }
}

if (!function_exists('formatDateDisplay')) {
    function formatDateDisplay(?string $value): string
    {
        if ($value === null || $value === '') {
            return '—';
        }

        $timestamp = strtotime((string) $value);

        if ($timestamp === false) {
            return (string) $value;
        }

        return date('M d, Y g:i A', $timestamp);
    }
}

if (!function_exists('buildNameMap')) {
    function buildNameMap(PDO $conn, string $table, string $idColumn, string $nameColumn): array
    {
        try {
            $stmt = $conn->query("SELECT `$idColumn`, `$nameColumn` FROM `$table`");
            $map = [];

            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                if (!array_key_exists($idColumn, $row) || !array_key_exists($nameColumn, $row)) {
                    continue;
                }

                $idValue = (string) $row[$idColumn];
                $nameValue = (string) $row[$nameColumn];
                $map[$idValue] = $nameValue;

                if (is_numeric($idValue)) {
                    $map[(int) $idValue] = $nameValue;
                }
            }

            return $map;
        } catch (Exception $e) {
            return [];
        }
    }
}

if (!function_exists('mapValueWithFallback')) {
    function mapValueWithFallback(?string $value, array $map): string
    {
        if ($value === null) {
            return '—';
        }

        $trimmed = trim((string) $value);

        if ($trimmed === '') {
            return '—';
        }

        if (array_key_exists($trimmed, $map)) {
            return $map[$trimmed];
        }

        if (is_numeric($trimmed)) {
            $numeric = (int) $trimmed;

            if (array_key_exists($numeric, $map)) {
                return $map[$numeric];
            }
        }

        return $trimmed;
    }
}

if (!function_exists('generateTempPassword')) {
    function generateTempPassword(int $length = 8): string
    {
        $alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
        $password = '';
        $maxIndex = strlen($alphabet) - 1;

        for ($i = 0; $i < $length; $i++) {
            $index = function_exists('random_int') ? random_int(0, $maxIndex) : mt_rand(0, $maxIndex);
            $password .= $alphabet[$index];
        }

        return $password;
    }
}
