<?php
    include '../components/connect.php';

    if (isset($_POST['login'])) {

        $identifier = $_POST['identifier'] ?? '';
        $identifier = filter_var($identifier, FILTER_SANITIZE_STRING);

        $pass = $_POST['pass'] ?? '';
        $hashedPass = sha1($pass);
        $hashedPass = filter_var($hashedPass, FILTER_SANITIZE_STRING);

        $select_admin = $conn->prepare("SELECT * FROM `admin` WHERE (email = ? OR name = ?) AND password = ? LIMIT 1");
        $select_admin->execute([$identifier, $identifier, $hashedPass]);

        if ($select_admin->rowCount() > 0) {
            $row = $select_admin->fetch(PDO::FETCH_ASSOC);
            setcookie('admin_id', $row['id'], time() + 60*60*24*30, '/');
            header('location:dashboard.php');
            exit;
        }

        $warning_msg[] = 'incorrect username/email or password';
    }

?>
<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>ClinicCare | Admin Login</title>
   <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
   <link rel="stylesheet" type="text/css" href="../css/auth_style.css?v=<?php echo time(); ?>">
</head>
<body class="auth-page admin">

    <div class="auth-card">
        <h1>Admin Login</h1>
        <p class="subtitle">Welcome back! Please login to your account.</p>

        <form action="" method="post" class="auth-form">
            <div class="input-field">
                <label for="identifier">Username or Email</label>
                <input id="identifier" type="text" name="identifier" placeholder="Enter your username or email" maxlength="70" required>
            </div>

            <div class="input-field">
                <label for="password">Password</label>
                <input id="password" type="password" name="pass" placeholder="Enter your password" maxlength="50" required>
            </div>

            <button type="submit" name="login" class="primary-action">Sign In</button>
        </form>

        <div class="link">Need an account? <a href="register.php">Register here</a></div>
        <div class="back-link"><a href="../login.php"><i class='bx bx-arrow-back'></i> Back to Home</a></div>
    </div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
<?php include '../components/alert.php'; ?>
</body>
</html>