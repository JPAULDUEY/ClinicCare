<?php
    include '../components/connect.php';
    require_once __DIR__ . '/admin_helpers.php';

    if (isset($_COOKIE['admin_id'])) {
        $admin_id = $_COOKIE['admin_id'];
    } else {
        $admin_id = '';
        header('location:login.php');
        exit;
    }

    $currentPage = basename($_SERVER['PHP_SELF']);

        $adminData = null;

        try {
            $profileStmt = $conn->prepare("SELECT * FROM `admin` WHERE id = ? LIMIT 1");
            $profileStmt->execute([$admin_id]);
            $adminData = $profileStmt->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (Exception $e) {
            $adminData = null;
        }

        $adminName = $adminData['name'] ?? 'Admin';

        $metrics = [
            'messages' => safeCount($conn, 'message'),
            'appointments' => safeCount($conn, 'appointments'),
            'services' => safeCount($conn, 'services'),
            'patients' => safeCount($conn, 'patients'),
            'insurance' => safeCount($conn, 'insurance'),
            'doctors' => safeCount($conn, 'doctors'),
        ];

        $appointmentColumns = fetchTableColumns($conn, 'appointments');
        $appointmentDateColumn = firstAvailableColumn($appointmentColumns, ['appointment_date', 'schedule_date', 'visit_date', 'created_at', 'booked_on', 'date', 'appointment_day']);
        $appointmentStatusColumn = firstAvailableColumn($appointmentColumns, ['status', 'appointment_status', 'current_status', 'state']);
        $appointmentDoctorColumn = firstAvailableColumn($appointmentColumns, ['doctor_name', 'doctor', 'doctor_id', 'doctorID']);
        $appointmentPatientColumn = firstAvailableColumn($appointmentColumns, ['patient_name', 'patient', 'patient_id', 'patientID']);

        $orderCandidates = [];

        if ($appointmentDateColumn) {
            $orderCandidates[] = $appointmentDateColumn;
        }

        $orderCandidates = array_merge($orderCandidates, ['updated_at', 'created_at', 'id', 'appointment_id']);
        $appointmentOrderColumn = firstAvailableColumn($appointmentColumns, $orderCandidates);

        $dailyTransactions = [];

        if ($appointmentDateColumn) {
            try {
                $selectFields = [
                    "DATE($appointmentDateColumn) AS day",
                    "COUNT(*) AS total_appointments"
                ];

                if ($appointmentPatientColumn) {
                    $selectFields[] = "COUNT(DISTINCT $appointmentPatientColumn) AS unique_patients";
                }

                if ($appointmentDoctorColumn) {
                    $selectFields[] = "COUNT(DISTINCT $appointmentDoctorColumn) AS unique_doctors";
                }

                $sql = "SELECT " . implode(', ', $selectFields) . " FROM `appointments` WHERE $appointmentDateColumn IS NOT NULL GROUP BY DATE($appointmentDateColumn) ORDER BY day DESC LIMIT 7";
                $transactionsStmt = $conn->prepare($sql);
                $transactionsStmt->execute();
                $dailyTransactions = array_reverse($transactionsStmt->fetchAll(PDO::FETCH_ASSOC) ?: []);
            } catch (Exception $e) {
                $dailyTransactions = [];
            }
        }

        $chartLabels = [];
        $chartPatients = [];
        $chartDoctors = [];

        foreach ($dailyTransactions as $row) {
            $labelDate = $row['day'] ?? null;

            if ($labelDate) {
                $timestamp = strtotime($labelDate);
                $chartLabels[] = $timestamp ? date('M j', $timestamp) : $labelDate;
            }

            $chartPatients[] = isset($row['unique_patients']) ? (int) $row['unique_patients'] : (int) ($row['total_appointments'] ?? 0);
            $chartDoctors[] = isset($row['unique_doctors']) ? (int) $row['unique_doctors'] : (int) ($row['total_appointments'] ?? 0);
        }

        $patientColumns = fetchTableColumns($conn, 'patients');
        $patientIdColumn = firstAvailableColumn($patientColumns, ['id', 'patient_id', 'patientID']);
        $patientNameColumn = firstAvailableColumn($patientColumns, ['name', 'full_name', 'fullname']);
        $patientNameMap = ($patientIdColumn && $patientNameColumn) ? buildNameMap($conn, 'patients', $patientIdColumn, $patientNameColumn) : [];

        $doctorColumns = fetchTableColumns($conn, 'doctors');
        $doctorIdColumn = firstAvailableColumn($doctorColumns, ['id', 'doctor_id', 'doctorID']);
        $doctorNameColumn = firstAvailableColumn($doctorColumns, ['name', 'full_name', 'fullname']);
        $doctorNameMap = ($doctorIdColumn && $doctorNameColumn) ? buildNameMap($conn, 'doctors', $doctorIdColumn, $doctorNameColumn) : [];

        $patientFlowConfig = [
            'waiting' => ['label' => 'Waiting Room', 'class' => 'waiting'],
            'exam' => ['label' => 'In Exam Room', 'class' => 'exam'],
            'lab' => ['label' => 'Lab / X-Ray', 'class' => 'lab'],
            'discharge' => ['label' => 'Awaiting Discharge', 'class' => 'discharge'],
            'complete' => ['label' => 'Complete Visit', 'class' => 'complete'],
        ];

        $patientFlowData = [];

        foreach ($patientFlowConfig as $key => $value) {
            $patientFlowData[$key] = 0;
        }

        if ($appointmentStatusColumn) {
            try {
                $statusStmt = $conn->prepare("SELECT $appointmentStatusColumn AS status_value, COUNT(*) AS total FROM `appointments` GROUP BY $appointmentStatusColumn");
                $statusStmt->execute();
                $statuses = $statusStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

                foreach ($statuses as $statusRow) {
                    $statusValue = strtolower((string) ($statusRow['status_value'] ?? ''));
                    $count = (int) ($statusRow['total'] ?? 0);

                    if ($statusValue === '') {
                        continue;
                    }

                    if (stripos($statusValue, 'wait') !== false) {
                        $patientFlowData['waiting'] += $count;
                    } elseif (stripos($statusValue, 'exam') !== false) {
                        $patientFlowData['exam'] += $count;
                    } elseif (stripos($statusValue, 'lab') !== false || stripos($statusValue, 'x-ray') !== false || stripos($statusValue, 'xray') !== false) {
                        $patientFlowData['lab'] += $count;
                    } elseif (stripos($statusValue, 'discharge') !== false) {
                        $patientFlowData['discharge'] += $count;
                    } elseif (stripos($statusValue, 'complete') !== false || stripos($statusValue, 'done') !== false || stripos($statusValue, 'finish') !== false) {
                        $patientFlowData['complete'] += $count;
                    } else {
                        $patientFlowData['waiting'] += $count;
                    }
                }
            } catch (Exception $e) {
                // Leave patient flow data at zero if the query fails.
            }
        }

        $recentAppointments = [];

        if (!empty($appointmentColumns)) {
            try {
                $recentSql = "SELECT * FROM `appointments`";

                if ($appointmentOrderColumn) {
                    $recentSql .= " ORDER BY $appointmentOrderColumn DESC";
                }

                $recentSql .= " LIMIT 5";
                $recentStmt = $conn->prepare($recentSql);
                $recentStmt->execute();
                $recentRows = $recentStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

                foreach ($recentRows as $row) {
                    $patientRaw = extractField($row, [$appointmentPatientColumn, 'patient_name', 'patient', 'patient_fullname']);
                    $doctorRaw = extractField($row, [$appointmentDoctorColumn, 'doctor_name', 'doctor']);
                    $statusRaw = extractField($row, [$appointmentStatusColumn, 'status', 'appointment_status']);
                    $timeRaw = extractField($row, [$appointmentDateColumn, 'schedule_date', 'visit_date', 'appointment_time', 'created_at', 'updated_at']);

                    $recentAppointments[] = [
                        'patient' => mapValueWithFallback($patientRaw, $patientNameMap),
                        'doctor' => mapValueWithFallback($doctorRaw, $doctorNameMap),
                        'status' => formatStatus($statusRaw),
                        'status_key' => slugifyStatus($statusRaw),
                        'time' => formatDateDisplay($timeRaw),
                    ];
                }
            } catch (Exception $e) {
                $recentAppointments = [];
            }
        }
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>ClinicCare | Admin Dashboard</title>
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
        <link rel="stylesheet" type="text/css" href="../css/admin_style.css?v=<?php echo time(); ?>">
    </head>
    <body>

    <?php include '../components/admin_header.php'; ?>

    <main class="admin-dashboard-wrapper">
        <div class="admin-dashboard-shell">
            <aside class="admin-template-nav">
                <div class="template-logo">
                    <span class="template-logo__brand">Clinic</span>
                    <button class="template-logo__toggle" type="button" aria-label="Toggle navigation">
                        <i class='bx bx-menu'></i>
                    </button>
                </div>
                <nav class="template-nav-list">
                    <a href="dashboard.php" class="template-nav-item<?= $currentPage === 'dashboard.php' ? ' active' : ''; ?>"><i class='bx bxs-dashboard'></i><span>Dashboard</span></a>
                    <a href="users.php" class="template-nav-item<?= $currentPage === 'users.php' ? ' active' : ''; ?>"><i class='bx bxs-user-account'></i><span>Users</span></a>
                    <a href="doctors.php" class="template-nav-item<?= $currentPage === 'doctors.php' ? ' active' : ''; ?>"><i class='bx bxs-user-voice'></i><span>Doctors</span></a>
                    <a href="services.php" class="template-nav-item<?= $currentPage === 'services.php' ? ' active' : ''; ?>"><i class='bx bx-list-ul'></i><span>Services</span></a>
                    <a href="add_service.php" class="template-nav-item<?= $currentPage === 'add_service.php' ? ' active' : ''; ?>"><i class='bx bx-plus-circle'></i><span>Add Service</span></a>
                    <a href="../home.php" class="template-nav-item"><i class='bx bx-log-out'></i><span>Logout</span></a>
                </nav>
            </aside>

            <section class="admin-dashboard-content">
                <div class="dashboard-header">
                    <div class="dashboard-headings">
                        <p class="breadcrumb">Admin / Dashboard</p>
                        <h1>Admin Dashboard</h1>
                        <span>Monitor patient flow and daily activity at a glance.</span>
                    </div>
                    <div class="dashboard-user">
                        <span class="dashboard-user__name">Welcome, <?= htmlspecialchars($adminName, ENT_QUOTES, 'UTF-8'); ?></span>
                        <a href="update.php" class="dashboard-user__action">Update Profile</a>
                    </div>
                </div>

                <div class="admin-dashboard-grid">
                    <section class="admin-chart-card">
                        <div class="card-header">
                            <h2>Daily Patient &amp; Doctor Transactions</h2>
                            <span>Last 7 days</span>
                        </div>
                        <div class="chart-area">
                            <?php if (empty($chartLabels)): ?>
                                <p class="empty-chart">No transaction data recorded yet.</p>
                            <?php endif; ?>
                            <canvas id="transactionsChart"></canvas>
                        </div>
                    </section>

                    <section class="admin-flow-card">
                        <div class="card-header">
                            <h2>Patient Flow Overview</h2>
                        </div>
                        <div class="flow-grid">
                            <?php foreach ($patientFlowConfig as $key => $meta): ?>
                                <div class="flow-card <?= $meta['class']; ?>">
                                    <span class="flow-count"><?= number_format($patientFlowData[$key] ?? 0); ?></span>
                                    <span class="flow-label"><?= htmlspecialchars($meta['label'], ENT_QUOTES, 'UTF-8'); ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </section>
                </div>

                <section class="admin-metrics-grid">
                    <div class="metric-card primary">
                        <p class="metric-label">Unread Messages</p>
                        <p class="metric-value"><?= number_format($metrics['messages']); ?></p>
                        <a class="metric-link" href="admin_message.php">See Messages</a>
                    </div>
                    <div class="metric-card accent">
                        <p class="metric-label">Appointments</p>
                        <p class="metric-value"><?= number_format($metrics['appointments']); ?></p>
                        <a class="metric-link" href="admin_appointment.php">View Appointments</a>
                    </div>
                    <div class="metric-card neutral">
                        <p class="metric-label">Registered Patients</p>
                        <p class="metric-value"><?= number_format($metrics['patients']); ?></p>
                        <a class="metric-link" href="users.php">Registered Patients</a>
                    </div>
                    <div class="metric-card warn">
                        <p class="metric-label">Registered Doctors</p>
                        <p class="metric-value"><?= number_format($metrics['doctors']); ?></p>
                        <a class="metric-link" href="doctors_application.php">Manage Doctors</a>
                    </div>
                    <div class="metric-card neutral">
                        <p class="metric-label">Services</p>
                        <p class="metric-value"><?= number_format($metrics['services']); ?></p>
                        <a class="metric-link" href="services.php">View Services</a>
                    </div>
                    <div class="metric-card primary">
                        <p class="metric-label">Insurance Applications</p>
                        <p class="metric-value"><?= number_format($metrics['insurance']); ?></p>
                        <a class="metric-link" href="view_insurance.php">View Insurance</a>
                    </div>
                </section>

                <section class="admin-table-card">
                    <div class="card-header">
                        <h2>Real-time Patient Status</h2>
                    </div>
                    <div class="table-wrapper">
                        <?php if (empty($recentAppointments)): ?>
                            <p class="empty-table">No appointments recorded yet.</p>
                        <?php else: ?>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Patient Name</th>
                                        <th>Doctor</th>
                                        <th>Status</th>
                                        <th>Last Update</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recentAppointments as $appointment): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($appointment['patient'], ENT_QUOTES, 'UTF-8'); ?></td>
                                            <td><?= htmlspecialchars($appointment['doctor'], ENT_QUOTES, 'UTF-8'); ?></td>
                                            <td><span class="status-chip status-<?= htmlspecialchars($appointment['status_key'], ENT_QUOTES, 'UTF-8'); ?>"><?= htmlspecialchars($appointment['status'], ENT_QUOTES, 'UTF-8'); ?></span></td>
                                            <td><?= htmlspecialchars($appointment['time'], ENT_QUOTES, 'UTF-8'); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </section>
            </section>
        </div>
    </main>

    <!----sweetalert cdn link----->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const chartLabels = <?= json_encode($chartLabels, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
        const patientSeries = <?= json_encode($chartPatients, JSON_NUMERIC_CHECK); ?>;
        const doctorSeries = <?= json_encode($chartDoctors, JSON_NUMERIC_CHECK); ?>;

        const chartCanvas = document.getElementById('transactionsChart');

        if (chartCanvas && Array.isArray(chartLabels) && chartLabels.length) {
            new Chart(chartCanvas, {
                type: 'line',
                data: {
                    labels: chartLabels,
                    datasets: [
                        {
                            label: 'Patients',
                            data: patientSeries,
                            fill: true,
                            borderColor: '#4f46e5',
                            backgroundColor: 'rgba(79, 70, 229, 0.18)',
                            tension: 0.4,
                            pointBackgroundColor: '#4f46e5',
                            pointBorderWidth: 2,
                            pointRadius: 4,
                            pointHoverRadius: 6
                        },
                        {
                            label: 'Doctors',
                            data: doctorSeries,
                            fill: true,
                            borderColor: '#22c55e',
                            backgroundColor: 'rgba(34, 197, 94, 0.18)',
                            tension: 0.4,
                            pointBackgroundColor: '#22c55e',
                            pointBorderWidth: 2,
                            pointRadius: 4,
                            pointHoverRadius: 6
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: true,
                            position: 'top',
                            labels: {
                                boxWidth: 12,
                                boxHeight: 12,
                                font: {
                                    size: 12
                                }
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(15, 23, 42, 0.85)',
                            padding: 12,
                            bodyFont: {
                                size: 12
                            },
                            titleFont: {
                                size: 12
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }
    </script>

    <!-----------custom js link------------->
    <script type="text/javascript" src="../js/admin_script.js"></script>

    <?php include '../components/alert.php'; ?>
    <?php include '../components/admin_footer.php'; ?>
    </body>
    </html>