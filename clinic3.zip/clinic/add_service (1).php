<?php
    include '../components/connect.php';

    if (isset($_COOKIE['admin_id'])) {
        $admin_id = $_COOKIE['admin_id'];
    }else{
        $admin_id = '';
        header('location:login.php');
    }

    if (isset($_POST['publish'])) {
        $id = unique_id();

        $name = $_POST['name'];
        $name = filter_var($name, FILTER_SANITIZE_STRING);

        $price = $_POST['price'];
        $price = filter_var($price, FILTER_SANITIZE_STRING);

        $department = $_POST['department'];
        $department = filter_var($department, FILTER_SANITIZE_STRING);

        $content = $_POST['content'];
        $content = filter_var($content, FILTER_SANITIZE_STRING);

        $image = $_FILES['image']['name'];
        $image = filter_var($image, FILTER_SANITIZE_STRING);
        $image_size = $_FILES['image']['size'];
        $image_tmp_name = $_FILES['image']['tmp_name'];
        $image_folder = '../uploaded_files/'.$image;

        $status = 'active';

        $select_image = $conn->prepare("SELECT * FROM `services` WHERE image = ?");
        $select_image->execute([$image]);

        if (isset($image)) {
            if ($select_image->rowCount() > 0) {
                $warning_msg[] = 'image name is repeated';
            }elseif ($image_size > 2000000) {
                $warning_msg[] = 'image size is too large';
            }else{
                move_uploaded_file($image_tmp_name, $image_folder);
            }
        }else{
            $image = '';
        }
        if ($select_image->rowCount() > 0 AND $image != '') {
            $warning_msg[] = 'please rename your image';
        }else{
            $insert_service = $conn->prepare("INSERT INTO `services`(id, name, price, department, image, service_detail, status) VALUES(?,?,?,?,?,?,?)");
            $insert_service->execute([$id, $name, $price, $department, $image, $content, $status]);

            $success_msg[] = 'Service added successfully';
        }

    }


    //save service as draft

    if (isset($_POST['draft'])) {
        $id = unique_id();

        $name = $_POST['name'];
        $name = filter_var($name, FILTER_SANITIZE_STRING);

        $price = $_POST['price'];
        $price = filter_var($price, FILTER_SANITIZE_STRING);

        $department = $_POST['department'];
        $department = filter_var($department, FILTER_SANITIZE_STRING);

        $content = $_POST['content'];
        $content = filter_var($content, FILTER_SANITIZE_STRING);

        $image = $_FILES['image']['name'];
        $image = filter_var($image, FILTER_SANITIZE_STRING);
        $image_size = $_FILES['image']['size'];
        $image_tmp_name = $_FILES['image']['tmp_name'];
        $image_folder = '../uploaded_files/'.$image;

        $status = 'deactive';

        $select_image = $conn->prepare("SELECT * FROM `services` WHERE image = ?");
        $select_image->execute([$image]);

        if (isset($image)) {
            if ($select_image->rowCount() > 0) {
                $warning_msg[] = 'image name is repeated';
            }elseif ($image_size > 2000000) {
                $warning_msg[] = 'image size is too large';
            }else{
                move_uploaded_file($image_tmp_name, $image_folder);
            }
        }else{
            $image = '';
        }
        if ($select_image->rowCount() > 0 AND $image != '') {
            $warning_msg[] = 'please rename your image';
        }else{
            $insert_service = $conn->prepare("INSERT INTO `services` (id, name, price, department, image, service_detail, status) VALUES(?,?,?,?,?,?,?)");
            $insert_service->execute([$id, $name, $price, $department, $image, $content, $status]);

            $success_msg[] = 'Service save as draft successfully';
        }

    }

?>
<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>ClinicCare</title>
   <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
   <link rel="stylesheet" type="text/css" href="../css/admin_style.css?v=<?php echo "time"; ?>">
</head>
<body>

    <?php include '../components/admin_header.php'; ?>

    <section class="add-service-section">
    <div class="content">
            <h3>Add service</h3>
            <p>ClinicCare is a trusted healthcare provider offering quality medical services<br>
            with compassion and professionalism.
            <br>Our experienced team delivers personalized care using modern technology to ensure your health and well-being</p>
            <a href="dashboard.php" class="btn">add service</a>
        </div>
    </section>

    <div class="dashboard">
        <div class="heading">
            <h1>add service</h1>
        </div>
        <div class="form-container">
            <form action="" method="post" enctype="multipart/form-data" class="register">
                <div class="flex">
                    <div class="col">
                        <div class="input-field">
                            <p>service name<span>*</span></p>
                            <input type="text" name="name" placeholder="add service name" required class="box">
                        </div>
                        <div class="input-field">
                            <p>service charge<span>*</span></p>
                            <input type="number" name="price" placeholder="add service charge" required class="box">
                        </div>
                    </div>
                    <div class="col">
                        <div class="input-field">
                            <p>service thumbnail<span>*</span></p>
                            <input type="file" name="image" accept="image/*" required class="box">
                        </div>
                        <div class="input-field">
                            <p>department<span>*</span></p>
                            <input type="text" name="department" placeholder="add service department" required class="box">
                        </div>
                    </div>
                </div>
                <div class="input-field">
                    <p>service description<span>*</span></p>
                    <textarea name="content" class="box" required placeholder="service description..."></textarea>
                </div>
                <div class="flex-btn">
                    <button type="submit" name="publish" class="btn">publish</button>
                    <button type="submit" name="draft" class="btn">save draft</button>
                </div>
            </form>
        </div>
    </div>


<!----sweetalert cdn link----->
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<!-----------custom js link------------->
<script type="text/javascript" src="../js/admin_script.js"></script>

<?php include '../components/admin_footer.php'; ?>
</body>
</html>