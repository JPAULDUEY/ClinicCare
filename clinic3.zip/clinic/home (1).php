<?php
    include 'components/connect.php';

    if (isset($_COOKIE['user_id'])) {
    	$user_id = $_COOKIE['user_id'];
    }else{
    	$user_id = '';
    }
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>ClinicCare</title>
	<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
	<link rel="stylesheet" type="text/css" href="css/user_style.css?v=<?php echo "time"; ?>">
</head>
<body>

    <?php include 'components/user_header.php'; ?>

<section class="home-section">
    <div class="content">
            <h3>Welcome to ClinicCare</h3>
            <span>Where every patient is treated with kindness, respect, and care.</span>
            <p>Where every patient is treated with kindness, respect, and care.
                <br>
                Wishing you comfort, healing, and hope
                <br>
                Where every patient is treated with kindness, respect, and care. 
                <br>Wishing you comfort, healing, and hope
            </p>
            <a href="about.php" class="btn">About Us</a>
        </div>
</section>
<div class="about-us">
    <div class="box-container">
        <div class="box">
            <div class="container">
                <div class="card">
                    <img width="100px" height="100" src="components/image/calendar11.png">
                    <h2>easy booking</h2>
                    <p>Quick & easy booking anytime</p>
                </div>
                <div class="card">
                    <img width="100px" height="100" src="components/image/secured.png">
                    <h2>full security</h2>
                    <p>Your data is fully protected with top-level security</p>
                </div>
                <div class="card">
                    <img width="100px" height="100" src="components/image/trusted1.png">
                    <h2>strong reputation</h2>
                    <p>High patient satisfaction ratings</p>
                </div>
                <div class="card">
                    <img width="100px" height="100" src="components/image/appointment1.png">
                    <h2>appointment time</h2>
                    <p>Get an appointment in a few clicks</p>
                </div>
            </div>
        </div>
        <div class="box">
            <h1>about our clinic</h1>
            <p>At ClinicCare, we are committed to delivering exceptional healthcare services with compassion, integrity, and innovation. With over 50 years of service, our hospital has become a trusted name in the community, offering comprehensive medical care across multiple specialties.</p>
            <div class="box-card">
                <img width="40px" height="300" src="components/image/doctor1.jpg" class="doc">
                <div class="detail">
                    <h2>Dr. Smith</h2>
                    <span>head doctor, orthodontist</span>
                    <p>I’m Dr. Smith, a licensed orthodontist specializing in creating healthy, confident smiles. I help patients of all ages straighten their teeth and correct bite issues using braces, clear aligners, and modern orthodontic techniques.</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!--------home page about section end-------->
<div class="help">
    <div class="box-container">
        <div class="box">
            <img src="components/image/doctors.png">
        </div>
        <div class="box">
            <span>we take care of your health</span>
            <h1>We are Providing Best & <br> Affordable Health Care.</h1>
            <p></p>
            <div class="flex-btn">
                <a href="about.php" class="btn">read more</a>
                <a href="team.php" class="btn">team of doctors</a>
            </div>
        </div>
    </div>
</div>
<!------------------feature section start-------------------->


<!----------------service section-------------------->
<div class="service">
    <div class="heading">
        <h1><span>CliniCare</span>Are here to Help</h1>
        <h1>you see better</h1>
    </div>
    <div class="box-container">
        <div class="card">
            <img width="100px" height="100" src="components/image/secured1.png">
            <h2>Quality & Safety</h2>
            <p>Our clinic utilizes state of the art technology and employs a team of true experts.</p>
        </div>
        <div class="card">
            <img width="100px" height="100" src="components/image/tech.png">
            <h2>Leading Technology</h2>
            <p>Our clinic utilizes state of the art technology and employs a team of true experts.</p>
        </div>
        <div class="card">
            <img width="100px" height="100" src="components/image/expert.png">
            <h2>Expert by Experience</h2>
            <p>Our clinic utilizes state of the art technology and employs a team of true experts.</p>
        </div>
        <div class="card">
            <img width="" height="" src="components/image/advance.png" class="img">
            <h2>advance technology</h2>
            <p>Our clinic utilizes state of the art technology and employs a team of true experts.</p>
        </div>
        <div class="card">
            <img width="" height="" src="components/image/health.png" class="img">
            <h2>healthcare solution</h2>
            <p>Our clinic utilizes state of the art technology and employs a team of true experts.</p>
        </div>
        <div class="card">
            <img width="" height="" src="components/image/time.png" class="img">
            <h2>24/7 availability</h2>
            <p>Our clinic utilizes state of the art technology and employs a team of true experts.</p>
        </div>
    </div>
</div>





<?php include 'components/user_footer.php'; ?>
<!----sweetalert cdn link----->
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<!-----------custom js link------------->
<script type="text/javascript" src="js/user_script.js"></script>

<?php include 'components/alert.php'; ?>
</body>
</html>