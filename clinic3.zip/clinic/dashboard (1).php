<?php
    include '../components/connect.php';

    if (isset($_COOKIE['admin_id'])) {
        $admin_id = $_COOKIE['admin_id'];
    }else{
        $admin_id = '';
        header('location:login.php');
    }

?>
<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>ClinicCare</title>
   <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
   <link rel="stylesheet" type="text/css" href="../css/admin_style.css?v=<?php echo "time"; ?>">
</head>
<body>

    <?php include '../components/admin_header.php'; ?>

    <section class="dashboard-section">
    <div class="content">
            <h3>Dashboard</h3>
            <p>ClinicCare is a trusted healthcare provider offering quality medical services<br>
            with compassion and professionalism.
            <br>Our experienced team delivers personalized care using modern technology to ensure your health and well-being</p>
            <a href="dashboard.php" class="btn">dashboard</a>
        </div>
    </section>

    <div class="dashboard">
        <div class="box-container">
            <div class="box">
                <h3>welcome</h3>
                <p><?= $fetch_profile['name']; ?></p>
                <a href="update.php" class="btn">update profile</a>
            </div>
            <div class="box">
                <?php 
                    $select_message = $conn->prepare("SELECT * FROM `message`");
                    $select_message->execute();
                    $num_of_msg = $select_message->rowCount();
                ?>
                <h3><?= $num_of_msg; ?></h3>
                <p>unread messages</p>
                <a href="admin_message.php" class="btn">see messages</a>
            </div>
            <div class="box">
                <?php 
                    $select_appointments = $conn->prepare("SELECT * FROM `appointments`");
                    $select_appointments->execute();
                    $num_of_appointments = $select_appointments->rowCount();
                ?>
                <h3><?= $num_of_appointments; ?></h3>
                <p>view appointments</p>
                <a href="admin_appointment.php" class="btn">view appointment</a>
            </div>
            <div class="box">
                <?php 
                    $select_services = $conn->prepare("SELECT * FROM `services`");
                    $select_services->execute();
                    $num_of_services = $select_services->rowCount();
                ?>
                <h3><?= $num_of_services; ?></h3>
                <p>view services</p>
                <a href="view_service.php" class="btn">view services</a>
            </div>
            <div class="box">
                <?php 
                    $select_patients = $conn->prepare("SELECT * FROM `patients`");
                    $select_patients->execute();
                    $num_of_patients = $select_patients->rowCount();
                ?>
                <h3><?= $num_of_patients; ?></h3>
                <p>registered patients</p>
                <a href="user_account.php" class="btn">registered patients</a>
            </div>
            <div class="box">
                <?php 
                    $select_insurance = $conn->prepare("SELECT * FROM `insurance`");
                    $select_insurance->execute();
                    $num_of_insurance = $select_insurance->rowCount();
                ?>
                <h3><?= $num_of_insurance; ?></h3>
                <p>insurance applications</p>
                <a href="view_insurance.php" class="btn">view insurance</a>
            </div>
            <div class="box">
                <?php 
                    $select_doctors = $conn->prepare("SELECT * FROM `doctors`");
                    $select_doctors->execute();
                    $num_of_doctors = $select_doctors->rowCount();
                ?>
                <h3><?= $num_of_doctors; ?></h3>
                <p>registered doctors</p>
                <a href="doctors_application.php" class="btn">doctors application</a>
            </div>
        </div>
    </div>


















<!----sweetalert cdn link----->
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<!-----------custom js link------------->
<script type="text/javascript" src="../js/admin_script.js"></script>

<?php include '../components/admin_footer.php'; ?>
</body>
</html>