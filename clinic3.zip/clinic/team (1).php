<?php
    include 'components/connect.php';

    if (isset($_COOKIE['user_id'])) {
    	$user_id = $_COOKIE['user_id'];
    }else{
    	$user_id = '';
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>ClinicCare</title>
	<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
	<link rel="stylesheet" type="text/css" href="css/user_style.css?v=<?php echo "time"; ?>">
</head>
<body>

    <?php include 'components/user_header.php'; ?>

<section class="team-section">
    <div class="content">
            <h3>Our team</h3>
            <p>A skilled team managing hospital operations, ensuring quality patient care, efficient services, and regulatory compliance.</p>
            <a href="home.php" class="btn">Home</a>
        </div>
</section>

<div class="team">
    <div class="heading">
        <h1><span>Our Team</span>Are here to Assist</h1>
        <h1>you anytime</h1>
    </div>
    <div class="box-container">
        <div class="card">
            <img width="100px" height="100" src="components/image/doctor21.png">
            <h2>Quality & Safety</h2>
            <p>Our clinic utilizes state of the art technology and employs a team of true experts.</p>
        </div>
        <div class="card">
            <img width="100px" height="100" src="components/image/doctor22.png">
            <h2>Leading Technology</h2>
            <p>Our clinic utilizes state of the art technology and employs a team of true experts.</p>
        </div>
        <div class="card">
            <img width="100px" height="100" src="components/image/doctor23.png">
            <h2>Expert by Experience</h2>
            <p>Our clinic utilizes state of the art technology and employs a team of true experts.</p>
        </div>
        <div class="card">
            <img width="" height="" src="components/image/doctor24.png" class="img">
            <h2>advance technology</h2>
            <p>Our clinic utilizes state of the art technology and employs a team of true experts.</p>
        </div>
        <div class="card">
            <img width="" height="" src="components/image/doctor25.png" class="img">
            <h2>healthcare solution</h2>
            <p>Our clinic utilizes state of the art technology and employs a team of true experts.</p>
        </div>
        <div class="card">
            <img width="" height="" src="components/image/doctor26.png" class="img">
            <h2>24/7 availability</h2>
            <p>Our clinic utilizes state of the art technology and employs a team of true experts.</p>
        </div>
    </div>
</div>





<?php include 'components/user_footer.php'; ?>
<!----sweetalert cdn link----->
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<!-----------custom js link------------->
<script type="text/javascript" src="js/user_script.js"></script>

<?php include 'components/alert.php'; ?>
</body>
</html>