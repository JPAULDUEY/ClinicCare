# PDS Landing Page

This project is a simple landing page for a healthcare platform, featuring sections for Home, About, and Login. The landing page is designed to provide users with easy access to essential information and services.

## Project Structure

The project is organized as follows:

```
pds-landing-page
├── src
│   ├── index.html          # Main entry point for the landing page
│   ├── sections
│   │   ├── home.html      # Content for the Home section
│   │   ├── about.html     # Content for the About section
│   │   └── login.html     # Main login page linking to user-specific templates
│   ├── templates
│   │   └── login
│   │       ├── admin.html  # Login template for admin users
│   │       ├── doctor.html # Login template for doctor users
│   │       └── patient.html # Login template for patient users
│   ├── styles
│   │   ├── main.css       # Main styles for the landing page
│   │   ├── home.css       # Styles specific to the Home section
│   │   ├── about.css      # Styles specific to the About section
│   │   └── login.css      # Styles specific to the Login section
│   └── scripts
│       ├── main.js        # Main JavaScript functionality for the landing page
│       └── login.js       # JavaScript functionality specific to the login process
└── README.md              # Documentation for the project
```

## Features

- **Home Section**: Provides an overview of the platform and its services.
- **About Section**: Contains information about the organization and its mission.
- **Login Section**: A unified login page that directs users to their respective login templates based on their roles (admin, doctor, patient).

## Getting Started

To get started with the project, clone the repository and open the `index.html` file in your web browser. You can navigate through the Home, About, and Login sections from the main landing page.

## Contributing

Contributions are welcome! Please feel free to submit a pull request or open an issue for any suggestions or improvements.

## License

This project is licensed under the MIT License. See the LICENSE file for more details.