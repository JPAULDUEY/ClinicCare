document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('login-form');
    const userTypeSelect = document.getElementById('user-type');

    loginForm.addEventListener('submit', function(event) {
        event.preventDefault();
        const userType = userTypeSelect.value;
        let loginTemplate;

        switch(userType) {
            case 'admin':
                loginTemplate = 'templates/login/admin.html';
                break;
            case 'doctor':
                loginTemplate = 'templates/login/doctor.html';
                break;
            case 'patient':
                loginTemplate = 'templates/login/patient.html';
                break;
            default:
                alert('Please select a user type.');
                return;
        }

        window.location.href = loginTemplate;
    });
});