document.addEventListener('DOMContentLoaded', function() {
    const homeLink = document.getElementById('home-link');
    const aboutLink = document.getElementById('about-link');
    const loginLink = document.getElementById('login-link');

    homeLink.addEventListener('click', function() {
        loadSection('home.html');
    });

    aboutLink.addEventListener('click', function() {
        loadSection('about.html');
    });

    loginLink.addEventListener('click', function() {
        loadSection('login.html');
    });

    function loadSection(section) {
        const contentDiv = document.getElementById('content');
        fetch(`sections/${section}`)
            .then(response => response.text())
            .then(data => {
                contentDiv.innerHTML = data;
            })
            .catch(error => {
                console.error('Error loading section:', error);
            });
    }

    // Load the home section by default
    loadSection('home.html');
});