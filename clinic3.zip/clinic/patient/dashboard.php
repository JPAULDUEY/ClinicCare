<?php
include '../components/connect.php';
require_once __DIR__ . '/../admin/admin_helpers.php';

// Add the unique_id function
function unique_id() {
    return substr(bin2hex(random_bytes(10)), 0, 20);
}

if (!isset($_COOKIE['patient_id'])) {
    header('location:login.php');
    exit;
}

// ...existing code...

$patientId = $_COOKIE['patient_id'];

try {
    $patientStmt = $conn->prepare('SELECT * FROM `patients` WHERE id = ? LIMIT 1');
    $patientStmt->execute([$patientId]);
    $patient = $patientStmt->fetch(PDO::FETCH_ASSOC) ?: null;
} catch (Exception $e) {
    $patient = null;
}

if (!$patient) {
    setcookie('patient_id', '', time() - 3600, '/');
    header('location:login.php');
    exit;
}

$patientName = trim((string) ($patient['name'] ?? 'Patient'));
$patientEmail = trim((string) ($patient['email'] ?? ''));
$patientContact = trim((string) ($patient['phone'] ?? ($patient['contact_number'] ?? '')));
$patientAddress = trim((string) ($patient['address'] ?? ''));

if (!isset($success_msg)) {
    $success_msg = [];
}
if (!isset($warning_msg)) {
    $warning_msg = [];
}
if (!isset($error_msg)) {
    $error_msg = [];
}
if (!isset($info_msg)) {
    $info_msg = [];
}

$formValues = [
    'full_name' => $patientName,
    'email' => $patientEmail,
    'contact_number' => $patientContact,
    'address' => $patientAddress,
    'doctor' => '',
    'doctor_custom' => '',
    'appointment_date' => '',
    'appointment_time' => '',
    'message' => '',
];

/**
 * Ensures the appointments table exists with a baseline schema when missing.
 */
function ensureAppointmentsBaseline(PDO $conn): void
{
    try {
        $conn->exec(
            "CREATE TABLE IF NOT EXISTS `appointments` (
                `id` VARCHAR(40) NOT NULL PRIMARY KEY,
                `patient_id` VARCHAR(40) NOT NULL,
                `patient_name` VARCHAR(150) NOT NULL,
                `email` VARCHAR(150) NOT NULL,
                `contact_number` VARCHAR(40) NOT NULL,
                `address` VARCHAR(255) NOT NULL,
                `doctor_id` VARCHAR(40) DEFAULT NULL,
                `doctor_name` VARCHAR(150) DEFAULT NULL,
                `appointment_date` DATE NOT NULL,
                `appointment_time` TIME NOT NULL,
                `message` TEXT NULL,
                `status` VARCHAR(60) NOT NULL DEFAULT 'Pending',
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
        );
    } catch (Exception $e) {
        // Table creation failure is non-blocking for existing databases.
    }
}

/**
 * Maps dynamic column names while preventing duplicates.
 */
function mapColumnWithUsage(array $columns, array $candidates, array &$used): ?string
{
    foreach ($candidates as $candidate) {
        if (!$candidate) {
            continue;
        }

        if (in_array($candidate, $columns, true) && !in_array($candidate, $used, true)) {
            $used[] = $candidate;
            return $candidate;
        }
    }

    return null;
}

function formatDateOnly(?string $value): string
{
    if ($value === null) {
        return '—';
    }

    $trimmed = trim($value);

    if ($trimmed === '') {
        return '—';
    }

    $patterns = ['Y-m-d', 'Y-m-d H:i:s', 'Y-m-d H:i'];

    foreach ($patterns as $pattern) {
        $date = DateTimeImmutable::createFromFormat($pattern, $trimmed);
        if ($date instanceof DateTimeImmutable) {
            return $date->format('M d, Y');
        }
    }

    return $trimmed;
}

function formatTimeOnly(?string $value): string
{
    if ($value === null) {
        return '—';
    }

    $trimmed = trim($value);

    if ($trimmed === '') {
        return '—';
    }

    $patterns = ['H:i:s', 'H:i'];

    foreach ($patterns as $pattern) {
        $time = DateTimeImmutable::createFromFormat($pattern, $trimmed);
        if ($time instanceof DateTimeImmutable) {
            return $time->format('g:i A');
        }
    }

    return $trimmed;
}

function normalizeStatusLabel(?string $status): array
{
    $raw = trim((string) ($status ?? ''));

    if ($raw === '') {
        return ['key' => 'pending', 'label' => 'No Action Yet', 'raw' => $raw];
    }

    $normalized = strtolower($raw);

    if (strpos($normalized, 'reject') !== false || strpos($normalized, 'cancel') !== false || strpos($normalized, 'decline') !== false) {
        return ['key' => 'rejected', 'label' => 'Rejected', 'raw' => $raw];
    }

    if (strpos($normalized, 'complete') !== false || strpos($normalized, 'finished') !== false || strpos($normalized, 'done') !== false) {
        return ['key' => 'completed', 'label' => 'Completed', 'raw' => $raw];
    }

    if (
        strpos($normalized, 'pending') !== false ||
        strpos($normalized, 'wait') !== false ||
        strpos($normalized, 'no action') !== false ||
        strpos($normalized, 'new') !== false ||
        strpos($normalized, 'scheduled') !== false
    ) {
        return ['key' => 'pending', 'label' => 'No Action Yet', 'raw' => $raw];
    }

    $cleanLabel = ucwords(str_replace(['_', '-'], ' ', $raw));

    return ['key' => 'pending', 'label' => $cleanLabel, 'raw' => $raw];
}

ensureAppointmentsBaseline($conn);

$appointmentColumns = fetchTableColumns($conn, 'appointments');

if (empty($appointmentColumns)) {
    ensureAppointmentsBaseline($conn);
    $appointmentColumns = fetchTableColumns($conn, 'appointments');
}

$usedAppointmentColumns = [];
$appointmentColumnMap = [
    'primary_id' => mapColumnWithUsage($appointmentColumns, ['id', 'appointment_id'], $usedAppointmentColumns),
    'patient_id' => mapColumnWithUsage($appointmentColumns, ['patient_id', 'patientID', 'patient_reference'], $usedAppointmentColumns),
    'patient_name' => mapColumnWithUsage($appointmentColumns, ['patient_name', 'patient', 'name'], $usedAppointmentColumns),
    'patient_email' => mapColumnWithUsage($appointmentColumns, ['email', 'email_address', 'patient_email'], $usedAppointmentColumns),
    'patient_contact' => mapColumnWithUsage($appointmentColumns, ['contact_number', 'phone', 'contact_no', 'phone_number', 'contact'], $usedAppointmentColumns),
    'patient_address' => mapColumnWithUsage($appointmentColumns, ['address', 'patient_address'], $usedAppointmentColumns),
    'doctor_id' => mapColumnWithUsage($appointmentColumns, ['doctor_id', 'doctorID'], $usedAppointmentColumns),
    'doctor_name' => mapColumnWithUsage($appointmentColumns, ['doctor_name', 'doctor'], $usedAppointmentColumns),
    'appointment_date' => mapColumnWithUsage($appointmentColumns, ['appointment_date', 'schedule_date', 'visit_date', 'appointment_day', 'date'], $usedAppointmentColumns),
    'appointment_time' => mapColumnWithUsage($appointmentColumns, ['appointment_time', 'schedule_time', 'appointment_slot', 'time'], $usedAppointmentColumns),
    'message' => mapColumnWithUsage($appointmentColumns, ['message', 'notes', 'remarks'], $usedAppointmentColumns),
    'status' => mapColumnWithUsage($appointmentColumns, ['status', 'appointment_status', 'current_status', 'state'], $usedAppointmentColumns),
    'created_at' => mapColumnWithUsage($appointmentColumns, ['created_at', 'booked_on', 'createdOn'], $usedAppointmentColumns),
    'updated_at' => mapColumnWithUsage($appointmentColumns, ['updated_at', 'modified_at'], $usedAppointmentColumns),
];

$doctorOptions = [];
$doctorLookup = [];

$doctorColumns = fetchTableColumns($conn, 'doctors');
$doctorIdColumn = firstAvailableColumn($doctorColumns, ['id', 'doctor_id', 'doctorID']);
$doctorNameColumn = firstAvailableColumn($doctorColumns, ['name', 'full_name', 'fullname']);

if ($doctorNameColumn !== null) {
    try {
        $selectFields = '`' . $doctorNameColumn . '` AS doctor_name';

        if ($doctorIdColumn !== null) {
            $selectFields .= ', `' . $doctorIdColumn . '` AS doctor_id';
        }

        $doctorStmt = $conn->prepare('SELECT ' . $selectFields . ' FROM `doctors` ORDER BY `' . $doctorNameColumn . '` ASC');
        $doctorStmt->execute();

        foreach ($doctorStmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row) {
            $nameValue = trim((string) ($row['doctor_name'] ?? ''));

            if ($nameValue === '') {
                continue;
            }

            $idValue = $doctorIdColumn !== null ? trim((string) ($row['doctor_id'] ?? '')) : '';
            $optionValue = $idValue !== '' ? $idValue : $nameValue;

            $doctorOptions[] = [
                'id' => $idValue !== '' ? $idValue : null,
                'name' => $nameValue,
                'value' => $optionValue,
            ];

            $doctorLookup[$optionValue] = [
                'id' => $idValue !== '' ? $idValue : null,
                'name' => $nameValue,
            ];
        }
    } catch (Exception $e) {
        $doctorOptions = [];
        $doctorLookup = [];
    }
}

$patientFilterColumn = null;
$patientFilterValue = null;

if ($appointmentColumnMap['patient_id']) {
    $patientFilterColumn = $appointmentColumnMap['patient_id'];
    $patientFilterValue = $patientId;
} elseif ($appointmentColumnMap['patient_name']) {
    $patientFilterColumn = $appointmentColumnMap['patient_name'];
    $patientFilterValue = $patientName;
}

if (isset($_GET['booked']) && $_GET['booked'] === '1') {
    $success_msg[] = 'Appointment booked successfully.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_appointment'])) {
    $formValues['full_name'] = trim((string) ($_POST['full_name'] ?? $patientName));
    $formValues['email'] = trim((string) ($_POST['email'] ?? $patientEmail));
    $formValues['contact_number'] = trim((string) ($_POST['contact_number'] ?? $patientContact));
    $formValues['address'] = trim((string) ($_POST['address'] ?? $patientAddress));
    $formValues['appointment_date'] = trim((string) ($_POST['appointment_date'] ?? ''));
    $formValues['appointment_time'] = trim((string) ($_POST['appointment_time'] ?? ''));
    $formValues['doctor'] = trim((string) ($_POST['doctor'] ?? ''));
    $formValues['doctor_custom'] = trim((string) ($_POST['doctor_custom'] ?? ''));
    $formValues['message'] = trim((string) ($_POST['message'] ?? ''));

    $fullName = trim(filter_var($formValues['full_name'], FILTER_SANITIZE_FULL_SPECIAL_CHARS));
    $emailAddress = trim(filter_var($formValues['email'], FILTER_SANITIZE_EMAIL));
    $contactNumber = trim(preg_replace('/[^0-9+\-\s]/', '', $formValues['contact_number']));
    $addressText = trim(filter_var($formValues['address'], FILTER_SANITIZE_FULL_SPECIAL_CHARS));
    $appointmentDate = $formValues['appointment_date'];
    $appointmentTime = $formValues['appointment_time'];
    $doctorSelection = $formValues['doctor'];
    $doctorCustom = trim(filter_var($formValues['doctor_custom'], FILTER_SANITIZE_FULL_SPECIAL_CHARS));
    $notes = trim(filter_var($formValues['message'], FILTER_SANITIZE_FULL_SPECIAL_CHARS));

    $selectedDoctorName = '';
    $selectedDoctorId = null;

    if ($doctorSelection !== '' && isset($doctorLookup[$doctorSelection])) {
        $selectedDoctorName = $doctorLookup[$doctorSelection]['name'];
        $selectedDoctorId = $doctorLookup[$doctorSelection]['id'];
    } elseif ($doctorCustom !== '') {
        $selectedDoctorName = $doctorCustom;
    } elseif (!empty($doctorOptions)) {
        $warning_msg[] = 'Please select a doctor.';
    }

    if ($fullName === '') {
        $warning_msg[] = 'Full name is required.';
    }

    if ($emailAddress === '') {
        $warning_msg[] = 'Email address is required.';
    }

    if ($contactNumber === '') {
        $warning_msg[] = 'Contact number is required.';
    }

    if ($addressText === '') {
        $warning_msg[] = 'Address is required.';
    }

    $appointmentDateTime = null;

    if ($appointmentDate !== '' && $appointmentTime !== '') {
        $appointmentDateTime = DateTime::createFromFormat('Y-m-d H:i', $appointmentDate . ' ' . $appointmentTime);

        if (!$appointmentDateTime) {
            $warning_msg[] = 'Please provide a valid appointment date and time.';
        } else {
            $now = new DateTime();

            if ($appointmentDateTime < $now) {
                $warning_msg[] = 'Please choose a future appointment slot.';
            }
        }
    } else {
        $warning_msg[] = 'Appointment date and time are required.';
    }

    if (empty($warning_msg) && empty($error_msg)) {
        if (!$appointmentColumnMap['appointment_date'] || !$appointmentColumnMap['appointment_time']) {
            $error_msg[] = 'Appointment schedule fields are missing in the database.';
        } elseif ($patientFilterColumn === null) {
            $error_msg[] = 'Patient reference column is missing in the appointments table.';
        } else {
            $insertColumns = [];
            $insertValues = [];

            if ($appointmentColumnMap['primary_id']) {
                $insertColumns[] = '`' . $appointmentColumnMap['primary_id'] . '`';
                $insertValues[] = unique_id();
            }

            if ($appointmentColumnMap['patient_id']) {
                $insertColumns[] = '`' . $appointmentColumnMap['patient_id'] . '`';
                $insertValues[] = $patientId;
            }

            if ($appointmentColumnMap['patient_name']) {
                $insertColumns[] = '`' . $appointmentColumnMap['patient_name'] . '`';
                $insertValues[] = $fullName;
            }

            if ($appointmentColumnMap['patient_email']) {
                $insertColumns[] = '`' . $appointmentColumnMap['patient_email'] . '`';
                $insertValues[] = $emailAddress;
            }

            if ($appointmentColumnMap['patient_contact']) {
                $insertColumns[] = '`' . $appointmentColumnMap['patient_contact'] . '`';
                $insertValues[] = $contactNumber;
            }

            if ($appointmentColumnMap['patient_address']) {
                $insertColumns[] = '`' . $appointmentColumnMap['patient_address'] . '`';
                $insertValues[] = $addressText;
            }

            if ($appointmentColumnMap['doctor_id'] && $selectedDoctorId !== null) {
                $insertColumns[] = '`' . $appointmentColumnMap['doctor_id'] . '`';
                $insertValues[] = $selectedDoctorId;
            }

            if ($appointmentColumnMap['doctor_name'] && $selectedDoctorName !== '') {
                $insertColumns[] = '`' . $appointmentColumnMap['doctor_name'] . '`';
                $insertValues[] = $selectedDoctorName;
            }

            $insertColumns[] = '`' . $appointmentColumnMap['appointment_date'] . '`';
            $insertValues[] = $appointmentDate;

            $insertColumns[] = '`' . $appointmentColumnMap['appointment_time'] . '`';
            $insertValues[] = $appointmentTime;

            if ($appointmentColumnMap['message']) {
                $insertColumns[] = '`' . $appointmentColumnMap['message'] . '`';
                $insertValues[] = $notes;
            }

            if ($appointmentColumnMap['status']) {
                $insertColumns[] = '`' . $appointmentColumnMap['status'] . '`';
                $insertValues[] = 'Pending';
            }

            $timestamp = date('Y-m-d H:i:s');

            if ($appointmentColumnMap['created_at']) {
                $insertColumns[] = '`' . $appointmentColumnMap['created_at'] . '`';
                $insertValues[] = $timestamp;
            }

            if ($appointmentColumnMap['updated_at']) {
                $insertColumns[] = '`' . $appointmentColumnMap['updated_at'] . '`';
                $insertValues[] = $timestamp;
            }

            if (!empty($insertColumns)) {
                $placeholders = implode(', ', array_fill(0, count($insertColumns), '?'));
                $columnsSql = implode(', ', $insertColumns);

                try {
                    $insertStmt = $conn->prepare('INSERT INTO `appointments` (' . $columnsSql . ') VALUES (' . $placeholders . ')');
                    $insertStmt->execute($insertValues);

                    header('location:dashboard.php?booked=1');
                    exit;
                } catch (PDOException $e) {
                    $error_msg[] = 'Unable to save your appointment right now. Please try again later.';
                }
            } else {
                $error_msg[] = 'No appointment data could be mapped to the database schema.';
            }
        }
    }
}

$appointmentsNormalized = [];
$upcomingAppointments = [];
$nowReference = new DateTimeImmutable('now');

if ($patientFilterColumn !== null) {
    try {
        $orderColumn = $appointmentColumnMap['appointment_date'] ?: ($appointmentColumnMap['created_at'] ?: $appointmentColumnMap['primary_id']);

        $historySql = 'SELECT * FROM `appointments` WHERE `' . $patientFilterColumn . '` = ?';

        if ($orderColumn) {
            $historySql .= ' ORDER BY `' . $orderColumn . '` DESC';
        }

        $historyStmt = $conn->prepare($historySql);
        $historyStmt->execute([$patientFilterValue]);

        $rows = $historyStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        foreach ($rows as $row) {
            $rawDate = $appointmentColumnMap['appointment_date'] ? trim((string) ($row[$appointmentColumnMap['appointment_date']] ?? '')) : '';
            $rawTime = $appointmentColumnMap['appointment_time'] ? trim((string) ($row[$appointmentColumnMap['appointment_time']] ?? '')) : '';
            $statusInfo = normalizeStatusLabel($appointmentColumnMap['status'] ? ($row[$appointmentColumnMap['status']] ?? null) : null);

            $doctorDisplay = '';

            if ($appointmentColumnMap['doctor_name']) {
                $doctorDisplay = trim((string) ($row[$appointmentColumnMap['doctor_name']] ?? ''));
            }

            if ($doctorDisplay === '' && $appointmentColumnMap['doctor_id']) {
                $doctorReference = trim((string) ($row[$appointmentColumnMap['doctor_id']] ?? ''));

                if ($doctorReference !== '' && isset($doctorLookup[$doctorReference])) {
                    $doctorDisplay = $doctorLookup[$doctorReference]['name'];
                }
            }

            $dateTimeCandidate = null;

            if ($rawDate !== '') {
                $combinations = [
                    $rawDate . ' ' . $rawTime,
                    $rawDate,
                ];

                $formats = ['Y-m-d H:i:s', 'Y-m-d H:i', 'Y-m-d'];

                foreach ($combinations as $combo) {
                    foreach ($formats as $format) {
                        $parsed = DateTimeImmutable::createFromFormat($format, trim($combo));

                        if ($parsed instanceof DateTimeImmutable) {
                            $dateTimeCandidate = $parsed;
                            break 2;
                        }
                    }
                }
            }

            $record = [
                'reference' => $appointmentColumnMap['primary_id'] ? (string) ($row[$appointmentColumnMap['primary_id']] ?? '') : '',
                'patient_name' => $appointmentColumnMap['patient_name'] ? (string) ($row[$appointmentColumnMap['patient_name']] ?? $patientName) : $patientName,
                'email' => $appointmentColumnMap['patient_email'] ? (string) ($row[$appointmentColumnMap['patient_email']] ?? $patientEmail) : $patientEmail,
                'contact' => $appointmentColumnMap['patient_contact'] ? (string) ($row[$appointmentColumnMap['patient_contact']] ?? $patientContact) : $patientContact,
                'address' => $appointmentColumnMap['patient_address'] ? (string) ($row[$appointmentColumnMap['patient_address']] ?? $patientAddress) : $patientAddress,
                'doctor' => $doctorDisplay,
                'date' => formatDateOnly($rawDate),
                'time' => formatTimeOnly($rawTime),
                'raw_date' => $rawDate,
                'raw_time' => $rawTime,
                'status' => $statusInfo,
                'message' => $appointmentColumnMap['message'] ? (string) ($row[$appointmentColumnMap['message']] ?? '') : '',
                'date_time' => $dateTimeCandidate,
            ];

            if ($dateTimeCandidate instanceof DateTimeImmutable && $statusInfo['key'] !== 'rejected') {
                if ($dateTimeCandidate >= $nowReference) {
                    $upcomingAppointments[] = $record;
                }
            }

            $appointmentsNormalized[] = $record;
        }
    } catch (Exception $e) {
        $appointmentsNormalized = [];
        $upcomingAppointments = [];
    }
}

$totalAppointments = count($appointmentsNormalized);
$pendingCount = 0;
$completedCount = 0;
$rejectedCount = 0;

foreach ($appointmentsNormalized as $record) {
    if ($record['status']['key'] === 'completed') {
        $completedCount++;
    } elseif ($record['status']['key'] === 'rejected') {
        $rejectedCount++;
    } else {
        $pendingCount++;
    }
}

usort($upcomingAppointments, static function (array $a, array $b): int {
    $first = $a['date_time'];
    $second = $b['date_time'];

    if ($first === null && $second === null) {
        return 0;
    }

    if ($first === null) {
        return 1;
    }

    if ($second === null) {
        return -1;
    }

    return $first <=> $second;
});

$upcomingPreview = array_slice($upcomingAppointments, 0, 3);
$recentHistory = array_slice($appointmentsNormalized, 0, 5);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ClinicCare | Patient Dashboard</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="../css/patient_dashboard.css?v=<?php echo time(); ?>">
</head>
<body class="patient-shell">
<div class="patient-app">
    <div class="patient-overlay" data-sidebar-overlay></div>
    <aside class="patient-sidebar">
        <div class="sidebar-header">
            <span class="sidebar-brand">ClinicCare</span>
            <button class="sidebar-close" type="button" data-sidebar-close aria-label="Close navigation">
                <i class='bx bx-x'></i>
            </button>
        </div>
        <nav class="patient-nav">
            <a href="#dashboard-home" class="patient-nav__link active"><i class='bx bxs-dashboard'></i><span>Dashboard</span></a>
            <a href="#book-appointment" class="patient-nav__link"><i class='bx bx-calendar-plus'></i><span>Book Appointment</span></a>
            <a href="#appointment-history" class="patient-nav__link"><i class='bx bx-history'></i><span>Appointment History</span></a>
            <a href="#profile-overview" class="patient-nav__link"><i class='bx bx-user-circle'></i><span>Profile</span></a>
            <a href="#medical-history" class="patient-nav__link"><i class='bx bx-notepad'></i><span>Medical History</span></a>
        </nav>
        <div class="sidebar-footer">
            <p class="patient-name">Logged in as<br><strong><?php echo htmlspecialchars($patientName, ENT_QUOTES, 'UTF-8'); ?></strong></p>
            <a href="../home.php" class="logout-link"><i class='bx bx-log-out'></i><span>Logout</span></a>
        </div>
    </aside>

    <div class="patient-main">
        <header class="patient-header">
            <button class="sidebar-toggle" type="button" data-sidebar-toggle aria-label="Toggle navigation">
                <i class='bx bx-menu'></i>
            </button>
            <div class="header-info">
                <p class="header-breadcrumb">Patient / Dashboard</p>
                <h1>Welcome back, <?php echo htmlspecialchars($patientName, ENT_QUOTES, 'UTF-8'); ?></h1>
                <span>Manage appointments, track history, and keep your profile up to date.</span>
            </div>
            <div class="header-profile">
                <span class="profile-name"><?php echo htmlspecialchars($patientName, ENT_QUOTES, 'UTF-8'); ?></span>
                <span class="profile-email"><?php echo htmlspecialchars($patientEmail, ENT_QUOTES, 'UTF-8'); ?></span>
                <a href="../contact.php" class="profile-logout"><i class='bx bx-log-out'></i> Logout</a>
            </div>
        </header>

        <main class="patient-content">
            <section id="dashboard-home" class="panel">
                <div class="panel-header">
                    <h2>Patient | Dashboard</h2>
                    <span>User / Dashboard</span>
                </div>

                <div class="summary-grid">
                    <div class="summary-card upcoming">
                        <p class="summary-label">Upcoming Appointments</p>
                        <p class="summary-value"><?php echo number_format(count($upcomingAppointments)); ?></p>
                    </div>
                    <div class="summary-card pending">
                        <p class="summary-label">Pending</p>
                        <p class="summary-value"><?php echo number_format($pendingCount); ?></p>
                    </div>
                    <div class="summary-card completed">
                        <p class="summary-label">Completed</p>
                        <p class="summary-value"><?php echo number_format($completedCount); ?></p>
                    </div>
                    <div class="summary-card rejected">
                        <p class="summary-label">Rejected</p>
                        <p class="summary-value"><?php echo number_format($rejectedCount); ?></p>
                    </div>
                </div>

                <div class="quick-actions">
                    <a href="#profile-overview" class="quick-card">
                        <i class='bx bx-user-circle'></i>
                        <h3>My Profile</h3>
                        <p>Update Profile</p>
                    </a>
                    <a href="#appointment-history" class="quick-card">
                        <i class='bx bx-calendar-alt'></i>
                        <h3>My Appointments</h3>
                        <p>View Appointment History</p>
                    </a>
                    <a href="#book-appointment" class="quick-card">
                        <i class='bx bx-calendar-check'></i>
                        <h3>Appointments</h3>
                        <p>Book Appointment</p>
                    </a>
                </div>

                <div class="upcoming-section">
                    <div class="section-title">
                        <h3>Next Appointments</h3>
                        <span>Recent and scheduled visits</span>
                    </div>

                    <?php if (!empty($upcomingPreview)): ?>
                        <div class="upcoming-grid">
                            <?php foreach ($upcomingPreview as $appointment): ?>
                                <article class="upcoming-card">
                                    <div class="upcoming-date">
                                        <i class='bx bx-calendar'></i>
                                        <span><?php echo htmlspecialchars($appointment['date'], ENT_QUOTES, 'UTF-8'); ?></span>
                                    </div>
                                    <div class="upcoming-time">
                                        <i class='bx bx-time-five'></i>
                                        <span><?php echo htmlspecialchars($appointment['time'], ENT_QUOTES, 'UTF-8'); ?></span>
                                    </div>
                                    <?php if ($appointment['doctor'] !== ''): ?>
                                        <p class="upcoming-doctor"><i class='bx bx-user-voice'></i> <?php echo htmlspecialchars($appointment['doctor'], ENT_QUOTES, 'UTF-8'); ?></p>
                                    <?php endif; ?>
                                    <span class="status-chip status-<?php echo htmlspecialchars($appointment['status']['key'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($appointment['status']['label'], ENT_QUOTES, 'UTF-8'); ?></span>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="empty-state">No upcoming appointments yet. Book your next visit to see it here.</p>
                    <?php endif; ?>
                </div>

                <div class="history-preview">
                    <div class="section-title">
                        <h3>Recent Activity</h3>
                        <span>Your five most recent appointments</span>
                    </div>

                    <?php if (!empty($recentHistory)): ?>
                        <ul class="history-list">
                            <?php foreach ($recentHistory as $record): ?>
                                <li class="history-item">
                                    <div>
                                        <p class="history-date"><?php echo htmlspecialchars($record['date'], ENT_QUOTES, 'UTF-8'); ?> · <?php echo htmlspecialchars($record['time'], ENT_QUOTES, 'UTF-8'); ?></p>
                                        <span class="history-doctor"><?php echo htmlspecialchars($record['doctor'] !== '' ? $record['doctor'] : 'Doctor not assigned', ENT_QUOTES, 'UTF-8'); ?></span>
                                    </div>
                                    <span class="status-chip status-<?php echo htmlspecialchars($record['status']['key'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($record['status']['label'], ENT_QUOTES, 'UTF-8'); ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p class="empty-state">No appointment history recorded yet.</p>
                    <?php endif; ?>
                </div>
            </section>

            <section id="book-appointment" class="panel">
                <div class="panel-header">
                    <h2>Patient | Book Appointment</h2>
                </div>

                <form action="" method="post" class="appointment-form">
                    <div class="form-grid">
                        <div class="form-field">
                            <label for="full_name">Full Name*</label>
                            <input id="full_name" type="text" name="full_name" value="<?php echo htmlspecialchars($formValues['full_name'], ENT_QUOTES, 'UTF-8'); ?>" maxlength="150" required>
                        </div>
                        <div class="form-field">
                            <label for="contact_number">Contact No*</label>
                            <input id="contact_number" type="text" name="contact_number" value="<?php echo htmlspecialchars($formValues['contact_number'], ENT_QUOTES, 'UTF-8'); ?>" maxlength="40" required>
                        </div>
                        <div class="form-field">
                            <label for="email">Email Address*</label>
                            <input id="email" type="email" name="email" value="<?php echo htmlspecialchars($formValues['email'], ENT_QUOTES, 'UTF-8'); ?>" maxlength="150" required>
                        </div>
                        <div class="form-field">
                            <label for="address">Address*</label>
                            <input id="address" type="text" name="address" value="<?php echo htmlspecialchars($formValues['address'], ENT_QUOTES, 'UTF-8'); ?>" maxlength="255" required>
                        </div>
                        <div class="form-field">
                            <label for="doctor">Doctors*</label>
                            <select id="doctor" name="doctor" <?php echo empty($doctorOptions) ? '' : 'required'; ?>>
                                <option value="">Select a doctor</option>
                                <?php foreach ($doctorOptions as $doctor): ?>
                                    <option value="<?php echo htmlspecialchars($doctor['value'], ENT_QUOTES, 'UTF-8'); ?>" <?php echo $doctor['value'] === $formValues['doctor'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($doctor['name'], ENT_QUOTES, 'UTF-8'); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <span class="field-help">No doctor listed? Enter a name below.</span>
                            <input type="text" name="doctor_custom" placeholder="Doctor name" value="<?php echo htmlspecialchars($formValues['doctor_custom'], ENT_QUOTES, 'UTF-8'); ?>">
                        </div>
                        <div class="form-group schedule">
                            <div class="form-field">
                                <label for="appointment_date">Date*</label>
                                <input id="appointment_date" type="date" name="appointment_date" value="<?php echo htmlspecialchars($formValues['appointment_date'], ENT_QUOTES, 'UTF-8'); ?>" required>
                            </div>
                            <div class="form-field">
                                <label for="appointment_time">Time*</label>
                                <input id="appointment_time" type="time" name="appointment_time" value="<?php echo htmlspecialchars($formValues['appointment_time'], ENT_QUOTES, 'UTF-8'); ?>" required>
                            </div>
                        </div>
                        <div class="form-field wide">
                            <label for="message">Message</label>
                            <textarea id="message" name="message" rows="4" maxlength="500" placeholder="Add any notes for the care team..."><?php echo htmlspecialchars($formValues['message'], ENT_QUOTES, 'UTF-8'); ?></textarea>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="reset" class="secondary">Cancel</button>
                        <button type="submit" name="book_appointment" class="primary">Book Now</button>
                    </div>
                </form>
            </section>

            <section id="appointment-history" class="panel">
                <div class="panel-header">
                    <h2>Patient | Appointment History</h2>
                </div>

                <div class="history-controls">
                    <div class="history-search">
                        <input type="search" placeholder="Search appointments" data-history-search>
                        <button type="button" aria-label="Search"><i class='bx bx-search'></i></button>
                    </div>
                </div>

                <div class="history-table-wrapper">
                    <?php if (!empty($appointmentsNormalized)): ?>
                        <table class="history-table">
                            <thead>
                                <tr>
                                    <th>Patient Name</th>
                                    <th>Contact No.</th>
                                    <th>Email Address</th>
                                    <th>Address</th>
                                    <th>Doctor</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Appointment Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($appointmentsNormalized as $record): ?>
                                    <?php
                                        $searchText = strtolower(
                                            trim(
                                                $record['patient_name'] . ' ' .
                                                $record['email'] . ' ' .
                                                $record['contact'] . ' ' .
                                                $record['address'] . ' ' .
                                                $record['doctor'] . ' ' .
                                                $record['date'] . ' ' .
                                                $record['status']['label']
                                            )
                                        );
                                    ?>
                                    <tr data-history-row data-history-text="<?php echo htmlspecialchars($searchText, ENT_QUOTES, 'UTF-8'); ?>">
                                        <td><?php echo htmlspecialchars($record['patient_name'], ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><?php echo htmlspecialchars($record['contact'], ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><?php echo htmlspecialchars($record['email'], ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><?php echo htmlspecialchars($record['address'], ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><?php echo htmlspecialchars($record['doctor'] !== '' ? $record['doctor'] : '—', ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><?php echo htmlspecialchars($record['date'], ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><?php echo htmlspecialchars($record['time'], ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><span class="status-chip status-<?php echo htmlspecialchars($record['status']['key'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($record['status']['label'], ENT_QUOTES, 'UTF-8'); ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="empty-state">You do not have any appointments yet. Book your first appointment to get started.</p>
                    <?php endif; ?>
                </div>
            </section>

            <section id="profile-overview" class="panel">
                <div class="panel-header">
                    <h2>Patient | Profile Overview</h2>
                </div>

                <div class="profile-card">
                    <div class="profile-row">
                        <span class="profile-label">Full Name</span>
                        <span class="profile-value"><?php echo htmlspecialchars($patientName, ENT_QUOTES, 'UTF-8'); ?></span>
                    </div>
                    <div class="profile-row">
                        <span class="profile-label">Email Address</span>
                        <span class="profile-value"><?php echo htmlspecialchars($patientEmail !== '' ? $patientEmail : '—', ENT_QUOTES, 'UTF-8'); ?></span>
                    </div>
                    <div class="profile-row">
                        <span class="profile-label">Contact Number</span>
                        <span class="profile-value"><?php echo htmlspecialchars($patientContact !== '' ? $patientContact : '—', ENT_QUOTES, 'UTF-8'); ?></span>
                    </div>
                    <div class="profile-row">
                        <span class="profile-label">Address</span>
                        <span class="profile-value"><?php echo htmlspecialchars($patientAddress !== '' ? $patientAddress : '—', ENT_QUOTES, 'UTF-8'); ?></span>
                    </div>
                    <p class="profile-help">Need to update your details? Contact the clinic front desk to request a profile update.</p>
                </div>
            </section>

            <section id="medical-history" class="panel">
                <div class="panel-header">
                    <h2>Patient | Medical History</h2>
                </div>
                <div class="medical-placeholder">
                    <i class='bx bx-health'></i>
                    <p>Medical history records will appear here once added by your care team.</p>
                </div>
            </section>
        </main>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
<script type="text/javascript" src="../js/patient_dashboard.js?v=<?php echo time(); ?>"></script>
<?php include '../components/alert.php'; ?>
</body>
</html>
