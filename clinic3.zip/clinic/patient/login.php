<?php
    include '../components/connect.php';

    if (isset($_COOKIE['patient_id'])) {
        header('location:dashboard.php');
        exit;
    }

    if (isset($_POST['login'])) {
        $email = $_POST['email'] ?? '';
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);

        $passInput = $_POST['pass'] ?? '';
        $hashedPass = sha1($passInput);
        $hashedPass = filter_var($hashedPass, FILTER_SANITIZE_STRING);

        $selectPatient = $conn->prepare("SELECT * FROM patients WHERE email = ? AND password = ? LIMIT 1");
        $selectPatient->execute([$email, $hashedPass]);

        if ($selectPatient->rowCount() > 0) {
            $patient = $selectPatient->fetch(PDO::FETCH_ASSOC);
            setcookie('patient_id', $patient['id'], time() + 60 * 60 * 24 * 30, '/');
            header('location:dashboard.php');
            exit;
        }

        $warning_msg[] = 'incorrect email or password';
    }
?>
<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>ClinicCare | Patient Login</title>
   <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
   <link rel="stylesheet" type="text/css" href="../css/auth_style.css?v=<?php echo time(); ?>">
</head>
<body class="auth-page patient">

    <div class="auth-card">
        <h1>Patient Login</h1>
        <p class="subtitle">Welcome back! Please login to your account.</p>

        <form action="" method="post" class="auth-form">
            <div class="input-field">
                <label for="email">Email Address</label>
                <input id="email" type="email" name="email" placeholder="Enter your email" maxlength="70" required>
            </div>

            <div class="input-field">
                <label for="password">Password</label>
                <input id="password" type="password" name="pass" placeholder="Enter your password" maxlength="50" required>
            </div>

            <button type="submit" name="login" class="primary-action">Sign In</button>
        </form>

        <div class="link">Don't have an account? <a href="register.php">Register here</a></div>
        <div class="back-link"><a href="../login.php"><i class='bx bx-arrow-back'></i> Back to Home</a></div>
    </div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
<?php include '../components/alert.php'; ?>
</body>
</html>
