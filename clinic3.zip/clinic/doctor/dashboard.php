<?php
// Use PDO connection instead of mysqli to match login.php
include '../components/connect.php'; // This should use PDO

require_once __DIR__ . '/../admin/admin_helpers.php';

if (!isset($_COOKIE['doctor_id'])) {
    header('location:../login.php'); // Fix the path
    exit;
}

$doctor_id = $_COOKIE['doctor_id'];

// Initialize message arrays
$success_msg = [];
$error_msg = [];
$warning_msg = [];
$info_msg = [];

function pickField(array $row, array $options): ?string
{
    foreach ($options as $option) {
        if (!$option) {
            continue;
        }
        if (!array_key_exists($option, $row)) {
            continue;
        }
        $value = $row[$option];
        if ($value === null) {
            continue;
        }
        $value = trim((string) $value);
        if ($value === '') {
            continue;
        }
        return $value;
    }

    return null;
}

function statusKey(?string $status): string
{
    $normalized = strtolower(trim((string) ($status ?? '')));

    if ($normalized === '') {
        return 'pending';
    }

    if (
        strpos($normalized, 'reject') !== false ||
        strpos($normalized, 'cancel') !== false ||
        strpos($normalized, 'decline') !== false ||
        strpos($normalized, 'no show') !== false ||
        strpos($normalized, 'missed') !== false
    ) {
        return 'rejected';
    }

    if (
        strpos($normalized, 'pending') !== false ||
        strpos($normalized, 'wait') !== false ||
        strpos($normalized, 'request') !== false ||
        strpos($normalized, 'hold') !== false ||
        strpos($normalized, 'process') !== false
    ) {
        return 'pending';
    }

    if (
        strpos($normalized, 'complete') !== false ||
        strpos($normalized, 'done') !== false ||
        strpos($normalized, 'finish') !== false ||
        strpos($normalized, 'accept') !== false ||
        strpos($normalized, 'approve') !== false ||
        strpos($normalized, 'confirm') !== false ||
        strpos($normalized, 'attend') !== false ||
        strpos($normalized, 'check') !== false ||
        strpos($normalized, 'resolved') !== false ||
        strpos($normalized, 'schedule') !== false
    ) {
        return 'accepted';
    }

    return 'accepted';
}

function parseAppointmentTimestamp(?string $dateValue, ?string $timeValue): ?int
{
    $dateValue = $dateValue !== null ? trim((string) $dateValue) : '';
    $timeValue = $timeValue !== null ? trim((string) $timeValue) : '';

    if ($dateValue === '' && $timeValue === '') {
        return null;
    }

    if ($dateValue !== '' && $timeValue !== '') {
        $timestamp = strtotime($dateValue . ' ' . $timeValue);
        if ($timestamp !== false) {
            return $timestamp;
        }
    }

    if ($dateValue !== '') {
        $timestamp = strtotime($dateValue);
        if ($timestamp !== false) {
            return $timestamp;
        }
    }

    if ($timeValue !== '') {
        $timestamp = strtotime(date('Y-m-d') . ' ' . $timeValue);
        if ($timestamp !== false) {
            return $timestamp;
        }
    }

    return null;
}

function extractDurationMinutes(array $row, ?string $durationColumn, ?string $startColumn, ?string $endColumn): float
{
    if ($durationColumn && array_key_exists($durationColumn, $row)) {
        $raw = trim((string) ($row[$durationColumn] ?? ''));

        if ($raw !== '') {
            if (is_numeric($raw)) {
                return (float) $raw;
            }

            if (preg_match('/([0-9]+(?:\.[0-9]+)?)/', $raw, $matches)) {
                return (float) $matches[1];
            }
        }
    }

    if ($startColumn && $endColumn && array_key_exists($startColumn, $row) && array_key_exists($endColumn, $row)) {
        $startValue = trim((string) ($row[$startColumn] ?? ''));
        $endValue = trim((string) ($row[$endColumn] ?? ''));

        if ($startValue !== '' && $endValue !== '') {
            $startTs = strtotime($startValue);
            $endTs = strtotime($endValue);

            if ($startTs !== false && $endTs !== false && $endTs > $startTs) {
                return ($endTs - $startTs) / 60;
            }
        }
    }

    return 0.0;
}

function formatCount($value, int $decimals = 0): string
{
    if ($decimals > 0) {
        return number_format((float) $value, $decimals);
    }

    return number_format((float) $value);
}

$doctorData = null;

try {
    // Fix the prepared statement - it was missing execute parameters
    $doctorStmt = $conn->prepare('SELECT * FROM `doctors` WHERE id = ? LIMIT 1');
    $doctorStmt->execute([$doctor_id]); // Add the parameter here
    $doctorData = $doctorStmt->fetch(PDO::FETCH_ASSOC) ?: null;
} catch (Exception $e) {
    $doctorData = null;
}

$doctorName = pickField($doctorData ?? [], ['name', 'full_name', 'fullname']) ?? 'Doctor';
$doctorEmail = pickField($doctorData ?? [], ['email', 'email_address']);
$doctorPhone = pickField($doctorData ?? [], ['phone', 'contact', 'mobile', 'contact_number']);
$doctorSpecialty = pickField($doctorData ?? [], ['specialty', 'specialisation', 'specialization', 'department', 'field', 'expertise']);

$appointmentColumns = fetchTableColumns($conn, 'appointments');
$appointmentIdColumn = firstAvailableColumn($appointmentColumns, ['id','appointment_id','appointmentId']);
$appointmentStatusColumn = firstAvailableColumn($appointmentColumns, ['status', 'appointment_status', 'state', 'current_status']);
$appointmentDateColumn = firstAvailableColumn($appointmentColumns, ['appointment_date', 'schedule_date', 'visit_date', 'date', 'booked_on']);
$appointmentTimeColumn = firstAvailableColumn($appointmentColumns, ['appointment_time', 'time', 'schedule_time', 'start_time', 'slot']);
$appointmentPatientColumn = firstAvailableColumn($appointmentColumns, ['patient_name', 'patient', 'client_name', 'customer_name']);
$patientReferenceColumn = firstAvailableColumn($appointmentColumns, ['patient_id', 'patientID', 'patient_reference']);
$doctorReferenceColumn = firstAvailableColumn($appointmentColumns, ['doctor_id', 'doctorID', 'doctor_reference']);
$doctorNameColumn = firstAvailableColumn($appointmentColumns, ['doctor_name', 'doctor']);

// Add missing column definitions
$purposeColumn = firstAvailableColumn($appointmentColumns, ['purpose', 'service', 'reason', 'concern', 'complaint', 'notes', 'message']);
$locationColumn = firstAvailableColumn($appointmentColumns, ['location', 'room', 'clinic', 'venue']);
$orderColumn = firstAvailableColumn($appointmentColumns, ['created_at', 'appointment_date', 'date', 'id']);
$durationColumn = firstAvailableColumn($appointmentColumns, ['duration', 'appointment_duration', 'length']);
$startColumn = firstAvailableColumn($appointmentColumns, ['start_time', 'appointment_time', 'time']);
$endColumn = firstAvailableColumn($appointmentColumns, ['end_time', 'finish_time']);

// Handle accept / reject actions submitted by doctor
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['appointment_action']) && !empty($_POST['appointment_id']) && $appointmentIdColumn) {
    $action = ($_POST['appointment_action'] === 'accept') ? 'accept' : 'reject';
    $apptId = trim((string) $_POST['appointment_id']);

    try {
        $selectSql = "SELECT * FROM `appointments` WHERE `$appointmentIdColumn` = ? LIMIT 1";
        $selStmt = $conn->prepare($selectSql);
        $selStmt->execute([$apptId]);
        $apptRow = $selStmt->fetch(PDO::FETCH_ASSOC);

        if (!$apptRow) {
            $error_msg[] = 'Appointment not found.';
        } else {
            // authorize: if appointment already assigned to another doctor, block
            $existingDoctorRef = $doctorReferenceColumn ? trim((string) ($apptRow[$doctorReferenceColumn] ?? '')) : '';
            if ($existingDoctorRef !== '' && $existingDoctorRef != $doctor_id) {
                $error_msg[] = 'You are not authorized to modify this appointment.';
            } else {
                $newStatus = ($action === 'accept') ? 'accepted' : 'rejected';
                $updates = [];
                $params = [];

                if ($appointmentStatusColumn) {
                    $updates[] = "`$appointmentStatusColumn` = ?";
                    $params[] = $newStatus;
                }

                if ($doctorReferenceColumn) {
                    $updates[] = "`$doctorReferenceColumn` = ?";
                    $params[] = $doctor_id;
                }

                if ($doctorNameColumn) {
                    $updates[] = "`$doctorNameColumn` = ?";
                    $params[] = $doctorName;
                }

                // update timestamp if column exists
                $updatedAtCol = firstAvailableColumn($appointmentColumns, ['updated_at', 'modified_at', 'updatedOn']);
                if ($updatedAtCol) {
                    $updates[] = "`$updatedAtCol` = ?";
                    $params[] = date('Y-m-d H:i:s');
                }

                $params[] = $apptId;
                $sql = "UPDATE `appointments` SET " . implode(', ', $updates) . " WHERE `$appointmentIdColumn` = ?";
                $upd = $conn->prepare($sql);
                $upd->execute($params);

                $success_msg[] = ($action === 'accept') ? 'Appointment accepted.' : 'Appointment rejected.';
                // refresh page state — continue to fetch appointments below so lists reflect changes
            }
        }
    } catch (Exception $e) {
        $error_msg[] = 'Unable to update appointment. Try again.';
    }
}

$appointments = [];

if (!empty($appointmentColumns)) {
    $whereClauses = [];
    $whereParams = [];

    if ($doctorReferenceColumn) {
        $whereClauses[] = "`$doctorReferenceColumn` = ?";
        $whereParams[] = $doctor_id;
    }

    if ($doctorNameColumn && $doctorName) {
        $whereClauses[] = "`$doctorNameColumn` = ?";
        $whereParams[] = $doctorName;
    }

    $sql = 'SELECT * FROM `appointments`';

    if (!empty($whereClauses)) {
        $sql .= ' WHERE ' . implode(' OR ', $whereClauses);
    }

    if ($orderColumn) {
        $sql .= " ORDER BY `$orderColumn` DESC";
    }

    try {
        $appointmentStmt = $conn->prepare($sql);
        $appointmentStmt->execute($whereParams);
        $appointments = $appointmentStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Exception $e) {
        $appointments = [];
    }
}

$patientColumns = fetchTableColumns($conn, 'patients');
$patientIdColumn = firstAvailableColumn($patientColumns, ['id', 'patient_id', 'patientID']);
$patientNameColumn = firstAvailableColumn($patientColumns, ['name', 'full_name', 'fullname']);
$patientEmailColumn = firstAvailableColumn($patientColumns, ['email', 'email_address']);
$patientContactColumn = firstAvailableColumn($patientColumns, ['contact_number', 'phone', 'mobile', 'contact']);
$patientAddressColumn = firstAvailableColumn($patientColumns, ['address', 'location', 'city']);

$todayKey = date('Y-m-d');
$todayAppointments = [];
$appointmentRequests = [];
$historyRecords = [];
$patientRegistry = [];
$patientIdsToFetch = [];
$notifications = [];

$acceptedCount = 0;
$pendingCount = 0;
$rejectedCount = 0;
$totalDurationMinutes = 0.0;

foreach ($appointments as $row) {
    // Extract the ID first
    $rawId = pickField($row, [$appointmentIdColumn, 'id', 'appointment_id']) ?? null;
    
    $rawStatus = pickField($row, [$appointmentStatusColumn, 'status', 'appointment_status', 'state']);
    $statusKey = statusKey($rawStatus);
    $statusLabel = ucwords(strtolower($rawStatus ?: 'pending'));

    if ($statusKey === 'accepted') {
        $acceptedCount++;
    } elseif ($statusKey === 'rejected') {
        $rejectedCount++;
    } else {
        $pendingCount++;
    }

    $dateValue = pickField($row, [$appointmentDateColumn, 'date', 'appointment_date', 'schedule_date', 'visit_date', 'created_at']);
    $timeValue = pickField($row, [$appointmentTimeColumn, 'time', 'appointment_time', 'schedule_time', 'start_time']);
    $timestamp = parseAppointmentTimestamp($dateValue, $timeValue);
    $dateDisplay = $timestamp ? date('M d, Y', $timestamp) : ($dateValue ?: '—');
    $timeDisplay = $timestamp ? date('g:i A', $timestamp) : ($timeValue ?: '—');
    $dayKey = $timestamp ? date('Y-m-d', $timestamp) : null;

    $purposeValue = pickField($row, [$purposeColumn, 'service', 'reason', 'purpose', 'concern', 'complaint', 'notes']);
    $purposeDisplay = $purposeValue !== null && trim($purposeValue) !== '' ? ucwords(trim($purposeValue)) : 'General Consultation';

    $locationValue = pickField($row, [$locationColumn, 'location', 'room', 'clinic']);
    $locationDisplay = $locationValue !== null && trim($locationValue) !== '' ? ucwords(trim($locationValue)) : null;

    $patientIdValue = pickField($row, [$patientReferenceColumn, 'patient_id', 'patientID']);
    $patientNameValue = pickField($row, [$appointmentPatientColumn, 'patient', 'client_name']);
    $patientDisplay = $patientNameValue ?: '—';

    $patientKey = null;

    if ($patientIdValue !== null && $patientIdValue !== '') {
        $patientKey = 'id:' . trim((string) $patientIdValue);
        $patientIdsToFetch[$patientIdValue] = true;
    } elseif ($patientDisplay !== '—') {
        $patientKey = 'name:' . strtolower($patientDisplay);
    } else {
        $patientKey = 'row:' . md5(json_encode($row));
    }

    if (!isset($patientRegistry[$patientKey])) {
        $patientRegistry[$patientKey] = [
            'id' => $patientIdValue,
            'name' => $patientDisplay,
            'email' => null,
            'contact' => null,
            'address' => null,
            'visits' => 0,
            'accepted' => false,
            'last_visit_ts' => null,
            'last_visit_label' => $dateDisplay,
            'status' => $statusKey,
            'status_label' => $statusLabel,
        ];
    }

    $patientRegistry[$patientKey]['visits']++;

    if ($statusKey === 'accepted') {
        $patientRegistry[$patientKey]['accepted'] = true;
    }

    if ($timestamp !== null) {
        if ($patientRegistry[$patientKey]['last_visit_ts'] === null || $timestamp > $patientRegistry[$patientKey]['last_visit_ts']) {
            $patientRegistry[$patientKey]['last_visit_ts'] = $timestamp;
            $patientRegistry[$patientKey]['last_visit_label'] = $dateDisplay;
            $patientRegistry[$patientKey]['status'] = $statusKey;
            $patientRegistry[$patientKey]['status_label'] = $statusLabel;
        }
    }

    if ($dayKey === $todayKey && $statusKey !== 'rejected') {
        $todayAppointments[] = [
            'id' => $rawId, // Now properly defined
            'patient' => $patientDisplay,
            'purpose' => $purposeDisplay,
            'status_label' => $statusLabel,
            'status_key' => $statusKey,
            'time' => $timeDisplay,
            'location' => $locationDisplay,
            'timestamp' => $timestamp ?? 0,
        ];
    }

    if ($statusKey === 'pending') {
        $appointmentRequests[] = [
            'id' => $rawId, // Now properly defined
            'patient' => $patientDisplay,
            'purpose' => $purposeDisplay,
            'status_label' => $statusLabel,
            'status_key' => $statusKey,
            'time' => $timeDisplay,
            'date' => $dateDisplay,
            'timestamp' => $timestamp ?? 0,
        ];
    }

    $historyRecords[] = [
        'id' => $rawId, // Now properly defined
        'patient' => $patientDisplay,
        'purpose' => $purposeDisplay,
        'status_label' => $statusLabel,
        'status_key' => $statusKey,
        'date' => $dateDisplay,
        'time' => $timeDisplay,
        'timestamp' => $timestamp ?? 0,
        'search_text' => strtolower($patientDisplay . ' ' . $purposeDisplay . ' ' . $statusLabel . ' ' . $dateDisplay . ' ' . $timeDisplay),
    ];

    $totalDurationMinutes += extractDurationMinutes($row, $durationColumn, $startColumn, $endColumn);
}

if (!empty($patientIdsToFetch) && $patientIdColumn) {
    $ids = array_keys($patientIdsToFetch);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));

    try {
        $patientStmt = $conn->prepare("SELECT * FROM `patients` WHERE `$patientIdColumn` IN ($placeholders)");
        $patientStmt->execute(array_values($ids));
        $patientRows = $patientStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

        foreach ($patientRows as $patientRow) {
            $registryKey = 'id:' . trim((string) ($patientRow[$patientIdColumn] ?? ''));

            if (!isset($patientRegistry[$registryKey])) {
                continue;
            }

            $patientRegistry[$registryKey]['name'] = pickField($patientRow, [$patientNameColumn, 'name', 'full_name', 'fullname']) ?? $patientRegistry[$registryKey]['name'];
            $patientRegistry[$registryKey]['email'] = pickField($patientRow, [$patientEmailColumn, 'email', 'email_address']);
            $patientRegistry[$registryKey]['contact'] = pickField($patientRow, [$patientContactColumn, 'contact', 'contact_number', 'phone', 'mobile']);
            $patientRegistry[$registryKey]['address'] = pickField($patientRow, [$patientAddressColumn, 'address', 'location', 'city']);
        }
    } catch (Exception $e) {
        // Patient enrichment unavailable.
    }
}

usort($todayAppointments, function ($a, $b) {
    return ($a['timestamp'] ?? 0) <=> ($b['timestamp'] ?? 0);
});

usort($appointmentRequests, function ($a, $b) {
    return ($a['timestamp'] ?? 0) <=> ($b['timestamp'] ?? 0);
});

usort($historyRecords, function ($a, $b) {
    return ($b['timestamp'] ?? 0) <=> ($a['timestamp'] ?? 0);
});

$acceptedPatients = array_values(array_filter($patientRegistry, function ($entry) {
    return !empty($entry['accepted']);
}));

usort($acceptedPatients, function ($a, $b) {
    return ($b['last_visit_ts'] ?? 0) <=> ($a['last_visit_ts'] ?? 0);
});

foreach ($appointmentRequests as $request) {
    if (count($notifications) >= 4) {
        break;
    }

    $notifications[] = [
        'label' => 'New Request',
        'description' => trim($request['patient'] . ' • ' . strtolower($request['purpose'])),
        'time' => trim($request['date'] . ' ' . $request['time']),
    ];
}

if (empty($notifications) && !empty($todayAppointments)) {
    foreach ($todayAppointments as $slot) {
        if (count($notifications) >= 4) {
            break;
        }

        $notifications[] = [
            'label' => 'Upcoming Visit',
            'description' => trim($slot['patient'] . ' • ' . strtolower($slot['purpose'])),
            'time' => trim($slot['time']),
        ];
    }
}

$totalAppointments = count($appointments);
$uniquePatients = count($acceptedPatients) ?: count($patientRegistry);

$hoursScheduled = 0.0;

if ($totalDurationMinutes > 0) {
    if ($totalDurationMinutes > 24) {
        $hoursScheduled = $totalDurationMinutes / 60;
    } else {
        $hoursScheduled = $totalDurationMinutes;
    }
} else {
    $hoursScheduled = $acceptedCount;
}

$stats = [
    [
        'label' => 'Total Appointments',
        'value' => formatCount($totalAppointments),
        'icon' => 'bxs-calendar-check',
    ],
    [
        'label' => 'Unique Patients',
        'value' => formatCount($uniquePatients),
        'icon' => 'bxs-user-detail',
    ],
    [
        'label' => 'Hours Scheduled',
        'value' => formatCount($hoursScheduled, $hoursScheduled >= 10 ? 0 : 1),
        'icon' => 'bx-time-five',
        'suffix' => 'hrs',
    ],
    [
        'label' => 'Pending Requests',
        'value' => formatCount($pendingCount),
        'icon' => 'bx-notification',
    ],
];

$todayLabel = date('M d, Y');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ClinicCare | Doctor Dashboard</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" type="text/css" href="../css/doctor_dashboard.css?v=<?php echo time(); ?>">
</head>
<body class="doctor-shell">
<div class="doctor-app">
    <div class="doctor-overlay" data-sidebar-overlay></div>
    <aside class="doctor-sidebar">
        <div class="sidebar-header">
            <span class="sidebar-brand">Clinic</span>
            <button type="button" class="sidebar-close" aria-label="Close navigation" data-sidebar-close>
                <i class='bx bx-x'></i>
            </button>
        </div>
        <nav class="doctor-nav">
            <a href="#dashboard-overview" class="doctor-nav__link active">
                <i class='bx bxs-dashboard'></i>
                <span>Dashboard</span>
            </a>
            <a href="#appointment-history" class="doctor-nav__link">
                <i class='bx bx-history'></i>
                <span>Appointment History</span>
            </a>
            <a href="#patient-directory" class="doctor-nav__link">
                <i class='bx bxs-user-voice'></i>
                <span>Patients</span>
            </a>
            <a href="#search-center" class="doctor-nav__link">
                <i class='bx bx-search'></i>
                <span>Search</span>
            </a>
        </nav>
        <div class="sidebar-footer">
            <div class="sidebar-profile">
                <span class="sidebar-name"><?php echo htmlspecialchars($doctorName, ENT_QUOTES, 'UTF-8'); ?></span>
                <?php if ($doctorSpecialty): ?>
                    <span class="sidebar-title"><?php echo htmlspecialchars($doctorSpecialty, ENT_QUOTES, 'UTF-8'); ?></span>
                <?php endif; ?>
            </div>
            <a class="logout-link" href="../components/doctor_logout.php">
                <i class='bx bx-log-out'></i>
                <span>Logout</span>
            </a>
        </div>
    </aside>

    <main class="doctor-main">
        <header class="doctor-header">
            <button type="button" class="sidebar-toggle" aria-label="Toggle navigation" data-sidebar-toggle>
                <i class='bx bx-menu'></i>
            </button>
            <div class="header-info">
                <p class="header-title">DASHBOARD</p>
                <h1>Hello Dr. <?php echo htmlspecialchars($doctorName, ENT_QUOTES, 'UTF-8'); ?></h1>
                <span>Welcome back! Review today's schedule and recent activity.</span>
            </div>
            <div class="header-profile">
                <?php if ($doctorSpecialty): ?>
                    <span class="profile-role"><?php echo htmlspecialchars($doctorSpecialty, ENT_QUOTES, 'UTF-8'); ?></span>
                <?php endif; ?>
                <?php if ($doctorEmail): ?>
                    <span class="profile-meta"><?php echo htmlspecialchars($doctorEmail, ENT_QUOTES, 'UTF-8'); ?></span>
                <?php endif; ?>
                <?php if ($doctorPhone): ?>
                    <span class="profile-meta"><?php echo htmlspecialchars($doctorPhone, ENT_QUOTES, 'UTF-8'); ?></span>
                <?php endif; ?>
            </div>
        </header>

        <div class="doctor-content">
            <section class="panel hero-panel" id="dashboard-overview" data-observe>
                <div class="hero-summary">
                    <div class="hero-text">
                        <p class="hero-subtitle">Today's Appointments</p>
                        <h2><?php echo htmlspecialchars($todayLabel, ENT_QUOTES, 'UTF-8'); ?></h2>
                        <span>Keep the momentum going with <?php echo htmlspecialchars(formatCount(count($todayAppointments)), ENT_QUOTES, 'UTF-8'); ?> visit(s) scheduled today.</span>
                    </div>
                    <ul class="hero-stats">
                        <?php foreach ($stats as $card): ?>
                            <li class="hero-card">
                                <div class="hero-icon">
                                    <i class='bx <?php echo htmlspecialchars($card['icon'], ENT_QUOTES, 'UTF-8'); ?>'></i>
                                </div>
                                <div class="hero-data">
                                    <span class="hero-value">
                                        <?php echo htmlspecialchars($card['value'], ENT_QUOTES, 'UTF-8'); ?>
                                        <?php if (isset($card['suffix'])): ?>
                                            <small><?php echo htmlspecialchars($card['suffix'], ENT_QUOTES, 'UTF-8'); ?></small>
                                        <?php endif; ?>
                                    </span>
                                    <span class="hero-label"><?php echo htmlspecialchars($card['label'], ENT_QUOTES, 'UTF-8'); ?></span>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </section>

            <section class="panel schedule-panel" data-observe>
                <div class="schedule-grid">
                    <div class="schedule-column">
                        <div class="panel-header">
                            <h2>Today's Schedule</h2>
                            <span>Review upcoming visits and prepare ahead.</span>
                        </div>
                        <?php if (empty($todayAppointments)): ?>
                            <p class="empty-state">No appointments scheduled for today.</p>
                        <?php else: ?>
                            <table class="schedule-table">
                                <thead>
                                    <tr>
                                        <th>Patient</th>
                                        <th>Purpose</th>
                                        <th>Time</th>
                                        <th>Status</th>
                                        <th>Location</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($todayAppointments as $slot): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($slot['patient'], ENT_QUOTES, 'UTF-8'); ?></td>
                                            <td><?php echo htmlspecialchars($slot['purpose'], ENT_QUOTES, 'UTF-8'); ?></td>
                                            <td><?php echo htmlspecialchars($slot['time'], ENT_QUOTES, 'UTF-8'); ?></td>
                                            <td><span class="status-chip status-<?php echo htmlspecialchars($slot['status_key'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($slot['status_label'], ENT_QUOTES, 'UTF-8'); ?></span></td>
                                            <td><?php echo htmlspecialchars($slot['location'] ?? '—', ENT_QUOTES, 'UTF-8'); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                    <div class="schedule-column">
                        <div class="panel-header">
                            <h2>Appointment Requests</h2>
                            <span>New bookings awaiting your confirmation.</span>
                        </div>
                        <?php if (empty($appointmentRequests)): ?>
                            <p class="empty-state">No pending requests at the moment.</p>
                        <?php else: ?>
                            <ul class="request-list">
                                <?php foreach ($appointmentRequests as $request): ?>
                                    <li class="request-item">
                                        <div class="request-main">
                                            <strong><?php echo htmlspecialchars($request['patient'], ENT_QUOTES, 'UTF-8'); ?></strong>
                                            <span><?php echo htmlspecialchars($request['purpose'], ENT_QUOTES, 'UTF-8'); ?></span>
                                        </div>
                                        <div class="request-meta">
                                            <span><?php echo htmlspecialchars($request['date'], ENT_QUOTES, 'UTF-8'); ?></span>
                                            <span><?php echo htmlspecialchars($request['time'], ENT_QUOTES, 'UTF-8'); ?></span>
                                        </div>

                                        <!-- Accept / Reject form -->
                                        <form method="post" class="request-actions" style="margin-top:8px; display:flex; gap:8px;">
                                            <input type="hidden" name="appointment_id" value="<?php echo htmlspecialchars($request['id'], ENT_QUOTES, 'UTF-8'); ?>">
                                            <button type="submit" name="appointment_action" value="accept" class="btn btn-accept" onclick="return confirm('Accept this appointment?')">Accept</button>
                                            <button type="submit" name="appointment_action" value="reject" class="btn btn-reject" onclick="return confirm('Reject this appointment?')">Reject</button>
                                        </form>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>

                        <div class="notifications">
                            <h3>Notifications</h3>
                            <?php if (empty($notifications)): ?>
                                <p class="empty-state">All caught up. No new notifications.</p>
                            <?php else: ?>
                                <ul class="notification-list">
                                    <?php foreach ($notifications as $note): ?>
                                        <li class="notification-item">
                                            <div class="notification-icon"><i class='bx bx-bell'></i></div>
                                            <div class="notification-body">
                                                <strong><?php echo htmlspecialchars($note['label'], ENT_QUOTES, 'UTF-8'); ?></strong>
                                                <span><?php echo htmlspecialchars($note['description'], ENT_QUOTES, 'UTF-8'); ?></span>
                                                <small><?php echo htmlspecialchars($note['time'], ENT_QUOTES, 'UTF-8'); ?></small>
                                            </div>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </section>

            <section class="panel history-panel" id="appointment-history" data-observe>
                <div class="panel-header">
                    <h2>Appointment History</h2>
                    <span>Accepted, completed, and rejected visits in one view.</span>
                </div>
                <div class="history-toolbar">
                    <input type="search" placeholder="Filter history..." data-history-filter>
                    <i class='bx bx-search'></i>
                </div>
                <div class="history-table-wrapper">
                    <table class="history-table">
                        <thead>
                            <tr>
                                <th>Patient</th>
                                <th>Reason</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($historyRecords)): ?>
                                <tr>
                                    <td colspan="5" class="empty-cell">No appointment records found.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($historyRecords as $record): ?>
                                    <tr data-history-row data-history-text="<?php echo htmlspecialchars($record['search_text'], ENT_QUOTES, 'UTF-8'); ?>">
                                        <td><?php echo htmlspecialchars($record['patient'], ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><?php echo htmlspecialchars($record['purpose'], ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><?php echo htmlspecialchars($record['date'], ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><?php echo htmlspecialchars($record['time'], ENT_QUOTES, 'UTF-8'); ?></td>
                                        <td><span class="status-chip status-<?php echo htmlspecialchars($record['status_key'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($record['status_label'], ENT_QUOTES, 'UTF-8'); ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>

            <section class="panel patient-panel" id="patient-directory" data-observe>
                <div class="panel-header">
                    <h2>Patients</h2>
                    <span>All patients with accepted appointments.</span>
                </div>
                <?php if (empty($acceptedPatients)): ?>
                    <p class="empty-state">No accepted patients to display yet.</p>
                <?php else: ?>
                    <ul class="patient-list">
                        <?php foreach ($acceptedPatients as $patient): ?>
                            <li class="patient-card">
                                <div class="patient-main">
                                    <strong><?php echo htmlspecialchars($patient['name'], ENT_QUOTES, 'UTF-8'); ?></strong>
                                    <?php if (!empty($patient['email'])): ?>
                                        <span><?php echo htmlspecialchars($patient['email'], ENT_QUOTES, 'UTF-8'); ?></span>
                                    <?php endif; ?>
                                    <?php if (!empty($patient['contact'])): ?>
                                        <span><?php echo htmlspecialchars($patient['contact'], ENT_QUOTES, 'UTF-8'); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="patient-meta">
                                    <span class="patient-last">Last visit: <?php echo htmlspecialchars($patient['last_visit_label'] ?? '—', ENT_QUOTES, 'UTF-8'); ?></span>
                                    <span class="patient-count">Visits: <?php echo htmlspecialchars(formatCount($patient['visits']), ENT_QUOTES, 'UTF-8'); ?></span>
                                    <span class="status-chip status-<?php echo htmlspecialchars($patient['status'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($patient['status_label'], ENT_QUOTES, 'UTF-8'); ?></span>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </section>

            <section class="panel search-panel" id="search-center" data-observe>
                <div class="panel-header">
                    <h2>Search</h2>
                    <span>Quickly find appointments by patient, status, or date.</span>
                </div>
                <div class="search-control">
                    <input type="search" placeholder="Search appointments..." data-search-input>
                    <i class='bx bx-search-alt-2'></i>
                </div>
                <ul class="search-results" data-search-container>
                    <?php if (empty($historyRecords)): ?>
                        <li class="search-empty">No appointment data available to search.</li>
                    <?php else: ?>
                        <?php foreach ($historyRecords as $record): ?>
                            <li class="search-item" data-search-row data-search-text="<?php echo htmlspecialchars($record['search_text'], ENT_QUOTES, 'UTF-8'); ?>">
                                <div class="search-primary">
                                    <strong><?php echo htmlspecialchars($record['patient'], ENT_QUOTES, 'UTF-8'); ?></strong>
                                    <span><?php echo htmlspecialchars($record['purpose'], ENT_QUOTES, 'UTF-8'); ?></span>
                                </div>
                                <div class="search-meta">
                                    <span><?php echo htmlspecialchars($record['date'], ENT_QUOTES, 'UTF-8'); ?></span>
                                    <span><?php echo htmlspecialchars($record['time'], ENT_QUOTES, 'UTF-8'); ?></span>
                                    <span class="status-chip status-<?php echo htmlspecialchars($record['status_key'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($record['status_label'], ENT_QUOTES, 'UTF-8'); ?></span>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </ul>
            </section>
        </div>
    </main>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
<script type="text/javascript" src="../js/doctor_dashboard.js?v=<?php echo time(); ?>"></script>
<?php include '../components/alert.php'; ?>
</body>
</html>
