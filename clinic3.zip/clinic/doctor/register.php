<?php
    include '../components/connect.php';

    if (isset($_COOKIE['doctor_id'])) {
        header('location:dashboard.php');
        exit;
    }

$warning_msg = [];
$success_msg = [];

if (isset($_POST['register'])) {
    $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $education = filter_var($_POST['education'], FILTER_SANITIZE_STRING);
    $specialisation = filter_var($_POST['specialisation'], FILTER_SANITIZE_STRING);
    $gender = $_POST['gender'];
    $contact = filter_var($_POST['contact'], FILTER_SANITIZE_STRING);
    $experience = filter_var($_POST['experience'], FILTER_SANITIZE_STRING);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Add unique_id function for generating doctor ID
    function unique_id() {
        return substr(bin2hex(random_bytes(10)), 0, 20);
    }
    
    // Generate unique ID for doctor
    $doctor_id = unique_id();
    
    // Handle image upload
    $image = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image_name = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];
        $ext = pathinfo($image_name, PATHINFO_EXTENSION);
        $rename = unique_id().'.'.$ext;
        $image_folder = '../uploaded_files/' . $rename;
        
        if (move_uploaded_file($image_tmp, $image_folder)) {
            $image = $rename;
        }
    } else {
        $image = 'default_profile.jpg';
    }

    // Validation
    if (empty($name) || empty($email) || empty($education) || empty($specialisation) || 
        empty($gender) || empty($contact) || empty($experience) || empty($password)) {
        $warning_msg[] = 'Please fill all required fields!';
    } elseif ($password !== $confirm_password) {
        $warning_msg[] = 'Passwords do not match!';
    } elseif (strlen($password) < 6) {
        $warning_msg[] = 'Password must be at least 6 characters long!';
    } else {
        // Check if email already exists
        $check_email = $conn->prepare("SELECT * FROM doctors WHERE email = ?");
        $check_email->execute([$email]);
        
        if ($check_email->rowCount() > 0) {
            $warning_msg[] = 'Email already exists!';
        } else {
            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert new doctor with ID
            $insert_doctor = $conn->prepare("INSERT INTO doctors (id, name, email, education, specialisation, gender, number, experience, password, profile, date_reg) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            
            if ($insert_doctor->execute([$doctor_id, $name, $email, $education, $specialisation, $gender, $contact, $experience, $hashed_password, $image])) {
                $success_msg[] = 'Registration successful! You can now login.';
            } else {
                $warning_msg[] = 'Registration failed! Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Doctor Registration</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../css/user_style.css?v=<?php echo time(); ?>">
    <style>
    .registration-card {
        max-width: 900px;
        padding: 2.5rem;
        margin: 2rem auto;
    }
    .registration-form .form-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 2rem;
        margin-bottom: 1.5rem;
    }
    .form-group {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }
    .form-group label {
        font-weight: 600;
        color: #374151;
        font-size: 0.95rem;
    }
    .required { color: #ef4444; }
    .form-group input, .form-group select {
        padding: 0.875rem 1rem;
        border: 2px solid #e5e7eb;
        border-radius: 8px;
        font-size: 0.95rem;
    }
    .phone-input {
        display: flex;
        align-items: center;
        border: 2px solid #e5e7eb;
        border-radius: 8px;
        padding: 0.875rem 1rem;
        gap: 0.75rem;
    }
    .phone-input input {
        border: none;
        padding: 0;
        flex: 1;
    }
    .register-btn {
        background: #10b981;
        color: white;
        padding: 1rem 2rem;
        border-radius: 8px;
        font-weight: 600;
        width: 100%;
        margin-top: 1rem;
        border: none;
        cursor: pointer;
    }
    @media (max-width: 768px) {
        .registration-form .form-grid {
            grid-template-columns: 1fr;
        }
    }
    </style>
</head>
<body class="auth-body">

<a href="login.php" class="auth-back"><i class='bx bx-arrow-back'></i> Back to Login</a>

<main class="auth-wrapper">
    <div class="auth-card registration-card">
        <h1>Doctor Registration</h1>
        <form method="post" enctype="multipart/form-data" class="registration-form">
            <div class="form-grid">
                <div class="form-group">
                    <label>Name <span class="required">*</span></label>
                    <input type="text" name="name" placeholder="enter your name" required>
                </div>
                <div class="form-group">
                    <label>Your Education <span class="required">*</span></label>
                    <input type="text" name="education" placeholder="your education" required>
                </div>
            </div>

            <div class="form-grid">
                <div class="form-group">
                    <label>Email <span class="required">*</span></label>
                    <input type="email" name="email" placeholder="enter your email" required>
                </div>
                <div class="form-group">
                    <label>Your Specialisation <span class="required">*</span></label>
                    <input type="text" name="specialisation" placeholder="your specialisation" required>
                </div>
            </div>

            <div class="form-grid">
                <div class="form-group">
                    <label>Select Gender <span class="required">*</span></label>
                    <select name="gender" required>
                        <option value="">select gender</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Contact Number <span class="required">*</span></label>
                    <div class="phone-input">
                        <span>🇮🇳</span>
                        <input type="tel" name="contact" placeholder="enter contact number" required>
                    </div>
                </div>
            </div>

            <div class="form-grid">
                <div class="form-group">
                    <label>Experience <span class="required">*</span></label>
                    <input type="text" name="experience" placeholder="enter your experience" required>
                </div>
                <div class="form-group">
                    <label>Your Password <span class="required">*</span></label>
                    <input type="password" name="password" placeholder="enter your password" required>
                </div>
            </div>

            <div class="form-grid">
                <div class="form-group">
                    <label>Select Profile <span class="required">*</span></label>
                    <input type="file" name="image" accept="image/*">
                </div>
                <div class="form-group">
                    <label>Confirm Password <span class="required">*</span></label>
                    <input type="password" name="confirm_password" placeholder="confirm your password" required>
                </div>
            </div>

            <p class="auth-note">Already Have An Account? <a href="login.php">Login Now</a></p>
            
            <button type="submit" name="register" class="register-btn">Register Now</button>
        </form>
    </div>
</main>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
<?php include '../components/alert.php'; ?>

<script>
// Example fix for appointment booking with doctor connection
function bookAppointment() {
    // Get selected doctor ID
    const doctorId = document.getElementById('doctor-select').value;
    
    if (!doctorId) {
        showModal('Please select a doctor first.');
        return;
    }
    
    // Check if doctor has available slots
    fetch(`get_doctor_slots.php?doctor_id=${doctorId}`)
        .then(response => response.json())
        .then(slots => {
            if (slots.length === 0) {
                showModal('Please choose a future appointment slot.');
            } else {
                showTimeSlots(slots);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showModal('Error loading appointment slots.');
        });
}
</script>

</body>
</html>