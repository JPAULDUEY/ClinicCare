<?php
    include '../components/connect.php';

    if (isset($_COOKIE['doctor_id'])) {
        header('location:dashboard.php');
        exit;
    }

    $warning_msg = [];

    if (isset($_POST['login'])) {
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        $passInput = $_POST['pass'];

        echo "DEBUG: Email = $email, Password = $passInput<br>";

        if (!empty($email) && !empty($passInput)) {
            // Prepare SQL to check if the email exists
            $selectDoctor = $conn->prepare("SELECT * FROM doctors WHERE email = ? LIMIT 1");
            $selectDoctor->execute([$email]);

            echo "DEBUG: Query executed. Row count: " . $selectDoctor->rowCount() . "<br>";

            if ($selectDoctor->rowCount() > 0) {
                $doctor = $selectDoctor->fetch(PDO::FETCH_ASSOC);
                
                echo "DEBUG: Doctor found. Stored password: " . $doctor['password'] . "<br>";
                echo "DEBUG: Input password: " . $passInput . "<br>";

                // Check if password is hashed or plain text
                $passwordValid = false;
                
                // First try password_verify for hashed passwords
                if (password_verify($passInput, $doctor['password'])) {
                    echo "DEBUG: Password verified with password_verify()<br>";
                    $passwordValid = true;
                } 
                // If that fails, check if it's a plain text password (for existing records)
                else if ($passInput === $doctor['password']) {
                    echo "DEBUG: Password matched as plain text<br>";
                    $passwordValid = true;
                    
                    // Update to hashed password for security
                    $hashedPassword = password_hash($passInput, PASSWORD_DEFAULT);
                    $updatePassword = $conn->prepare("UPDATE doctors SET password = ? WHERE id = ?");
                    $updatePassword->execute([$hashedPassword, $doctor['id']]);
                } else {
                    echo "DEBUG: Password verification failed<br>";
                }

                if ($passwordValid) {
                    echo "DEBUG: Login successful! Setting cookie and redirecting...<br>";
                    // Set cookie for 30 days
                    setcookie('doctor_id', $doctor['id'], time() + (60 * 60 * 24 * 30), '/');
                    
                    // Add a delay to see the debug message
                    sleep(2);
                    
                    header('Location: dashboard.php');
                    exit;
                } else {
                    $warning_msg[] = 'Incorrect email or password.';
                }
            } else {
                echo "DEBUG: No doctor found with email: $email<br>";
                $warning_msg[] = 'Incorrect email or password.';
            }
        } else {
            $warning_msg[] = 'Please enter both email and password.';
        }
    }
?>

<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>ClinicCare | Doctor Login</title>
   <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
   <link rel="stylesheet" type="text/css" href="../css/auth_style.css?v=<?php echo time(); ?>">
</head>
<body class="auth-page doctor">

    <div class="auth-card">
        <h1>Doctor Login</h1>
        <p class="subtitle">Welcome back! Please login to your account.</p>

        <form action="" method="post" class="auth-form">
            <div class="input-field">
                <label for="email">Email Address</label>
                <input id="email" type="email" name="email" placeholder="Enter your email" maxlength="70" required>
            </div>

            <div class="input-field">
                <label for="password">Password</label>
                <input id="password" type="password" name="pass" placeholder="Enter your password" maxlength="50" required>
            </div>

            <button type="submit" name="login" class="primary-action green">Sign In</button>
        </form>

        <p class="auth-note">New doctor? <a href="register.php">Register here</a> | Need help? Contact your administrator.</p>

        <div class="back-link"><a href="../login.php"><i class='bx bx-arrow-back'></i> Back to Home</a></div>
    </div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
<?php include '../components/alert.php'; ?>
</body>
</html>