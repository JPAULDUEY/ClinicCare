<?php
include 'components/connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>About | ClinicCare</title>
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/user_style.css?v=<?php echo time(); ?>">
</head>
<body>
<?php include 'components/user_header.php'; ?>

<section class="about-hero">
    <div class="container">
        <h1>About ClinicCare</h1>
        <p>Delivering compassionate, innovative healthcare to our community since 1975.</p>
    </div>
</section>

<section class="about-story">
    <div class="container split">
        <div>
            <h2>Our story</h2>
            <p>ClinicCare was founded by local physicians with a shared goal: make quality care accessible to every family. Today our multi-disciplinary team provides comprehensive diagnostics, specialty services, and preventative programs under one roof.</p>
            <p>From routine checkups to complex treatments, we combine clinical expertise with modern technology to deliver personalized care paths tailored to each patient’s needs.</p>
        </div>
        <aside>
            <h3>Quick facts</h3>
            <ul>
                <li>50+ years serving the Dagupan community</li>
                <li>24/7 emergency and telehealth support</li>
                <li>Integrated digital records and patient portal</li>
                <li>Accredited specialists across 20+ disciplines</li>
            </ul>
        </aside>
    </div>
</section>

<section class="about-values">
    <div class="container">
        <h2>What guides us</h2>
        <div class="cards">
            <article>
                <h3>Compassion</h3>
                <p>Every interaction is rooted in empathy, respect, and dignity.</p>
            </article>
            <article>
                <h3>Excellence</h3>
                <p>We invest in ongoing training and technology to elevate patient outcomes.</p>
            </article>
            <article>
                <h3>Community</h3>
                <p>We collaborate with local partners to advance public health initiatives.</p>
            </article>
        </div>
    </div>
</section>

<?php include 'components/user_footer.php'; ?>
<script src="js/user_script.js"></script>
<?php include 'components/alert.php'; ?>
</body>
</html>
