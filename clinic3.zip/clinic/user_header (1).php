<div class="header">
	<section class="flex">
		<a href="home.php" class="logo"><img src="components/image/cliniccare.png" width="130"></a>
		<nav class="navbar">
			<a href="home.php" style="margin: .5rem;">home</a>
			<a href="about.php" style="margin: .5rem;">about</a>
			<a href="service.php" style="margin: .5rem;">service</a>
			<a href="team.php" style="margin: .5rem;">team</a>
			<a href="contact.php" style="margin: .5rem;">contact</a>
		</nav>
		<form action="search_service.php" method="post" class="search_form">
			<input type="text" name="search_service" placeholder="search_service..." required maxlength="100">

			<button type="submit" class="bx bx-search-alt-2" name="search_service_btn"></button>	
		</form>
		<div class="icons">
			<div id="menu-btn" class="bx bx-menu"></div>
			<div id="search-btn" class="bx bx-search-alt-2"></div>
			<div id="user-btn" class="bx bxs-user"></div>
		</div>
		<div class="profile" style="background-image: none;">
			<?php
			    if (isset($_COOKIE['user_id'])) {
				    // User is logged in, show dashboard button
			    
			?>
			    <a href="patient/dashboard.php" class="btn">dashboard</a>
			<?php }else{ ?>
				<a href="patient/login.php" class="btn">for patient</a>
			<?php } ?>
			<a href="doctor/login.php" class="btn">for doctor</a>
			<a href="admin/login.php" class="btn">for admin</a>
		</div>
	</section>
</div>

<script type="text/javascript" src="js/user_script.js"></script>