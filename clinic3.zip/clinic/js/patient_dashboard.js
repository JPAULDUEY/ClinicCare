document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.querySelector('.patient-sidebar');
    const overlay = document.querySelector('[data-sidebar-overlay]');
    const toggleButton = document.querySelector('[data-sidebar-toggle]');
    const closeButton = document.querySelector('[data-sidebar-close]');
    const navLinks = document.querySelectorAll('.patient-nav__link');
    const sections = document.querySelectorAll('main.section, main .panel');
    const searchInput = document.querySelector('[data-history-search]');
    const historyRows = document.querySelectorAll('[data-history-row]');

    const openSidebar = () => {
        if (!sidebar) {
            return;
        }

        sidebar.classList.add('open');

        if (overlay) {
            overlay.classList.add('visible');
        }
    };

    const closeSidebar = () => {
        if (!sidebar) {
            return;
        }

        sidebar.classList.remove('open');

        if (overlay) {
            overlay.classList.remove('visible');
        }
    };

    if (toggleButton) {
        toggleButton.addEventListener('click', () => {
            if (sidebar && sidebar.classList.contains('open')) {
                closeSidebar();
            } else {
                openSidebar();
            }
        });
    }

    if (closeButton) {
        closeButton.addEventListener('click', closeSidebar);
    }

    if (overlay) {
        overlay.addEventListener('click', closeSidebar);
    }

    const setActiveLink = (targetLink) => {
        navLinks.forEach((link) => {
            link.classList.toggle('active', link === targetLink);
        });
    };

    navLinks.forEach((link) => {
        link.addEventListener('click', (event) => {
            const href = link.getAttribute('href') || '';

            if (href.startsWith('#')) {
                event.preventDefault();
                const targetId = href.substring(1);
                const targetSection = document.getElementById(targetId);

                if (targetSection) {
                    targetSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    setActiveLink(link);
                    closeSidebar();
                }
            }
        });
    });

    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    const sectionId = entry.target.getAttribute('id');

                    navLinks.forEach((link) => {
                        const href = link.getAttribute('href') || '';
                        const matches = href === `#${sectionId}`;
                        link.classList.toggle('active', matches);
                    });
                }
            });
        }, {
            rootMargin: '-40% 0px -35% 0px',
            threshold: 0.1
        });

        sections.forEach((section) => observer.observe(section));
    }

    if (searchInput && historyRows.length) {
        const filterHistory = () => {
            const query = searchInput.value.trim().toLowerCase();

            historyRows.forEach((row) => {
                const haystack = row.getAttribute('data-history-text') || '';
                const match = haystack.includes(query);
                row.style.display = match ? '' : 'none';
            });
        };

        searchInput.addEventListener('input', filterHistory);
    }
});
