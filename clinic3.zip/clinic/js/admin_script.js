const profilePanel = document.querySelector('.profile-detail');
const profileToggle = document.getElementById('user-btn');

if (profilePanel && profileToggle) {
	profileToggle.addEventListener('click', () => {
		profilePanel.classList.toggle('active');
	});

	document.addEventListener('click', (event) => {
		if (!profilePanel.contains(event.target) && event.target !== profileToggle) {
			profilePanel.classList.remove('active');
		}
	});
}
