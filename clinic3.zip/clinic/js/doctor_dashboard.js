document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.querySelector('.doctor-sidebar');
    const overlay = document.querySelector('[data-sidebar-overlay]');
    const toggleButton = document.querySelector('[data-sidebar-toggle]');
    const closeButton = document.querySelector('[data-sidebar-close]');
    const navLinks = document.querySelectorAll('.doctor-nav__link');
    const observedSections = document.querySelectorAll('[data-observe]');
    const historyFilter = document.querySelector('[data-history-filter]');
    const historyRows = document.querySelectorAll('[data-history-row]');
    const searchInput = document.querySelector('[data-search-input]');
    const searchRows = document.querySelectorAll('[data-search-row]');

    const openSidebar = () => {
        if (!sidebar) {
            return;
        }

        sidebar.classList.add('open');

        if (overlay) {
            overlay.classList.add('visible');
        }
    };

    const closeSidebar = () => {
        if (!sidebar) {
            return;
        }

        sidebar.classList.remove('open');

        if (overlay) {
            overlay.classList.remove('visible');
        }
    };

    if (toggleButton) {
        toggleButton.addEventListener('click', () => {
            if (sidebar && sidebar.classList.contains('open')) {
                closeSidebar();
            } else {
                openSidebar();
            }
        });
    }

    if (closeButton) {
        closeButton.addEventListener('click', closeSidebar);
    }

    if (overlay) {
        overlay.addEventListener('click', closeSidebar);
    }

    const setActiveLink = (activeLink) => {
        navLinks.forEach((link) => {
            link.classList.toggle('active', link === activeLink);
        });
    };

    navLinks.forEach((link) => {
        link.addEventListener('click', (event) => {
            const href = link.getAttribute('href') || '';

            if (href.startsWith('#')) {
                event.preventDefault();
                const targetId = href.substring(1);
                const targetSection = document.getElementById(targetId);

                if (targetSection) {
                    targetSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    setActiveLink(link);
                    closeSidebar();
                }
            }
        });
    });

    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (!entry.isIntersecting) {
                    return;
                }

                const sectionId = entry.target.getAttribute('id');

                navLinks.forEach((link) => {
                    const href = link.getAttribute('href') || '';
                    const matches = href === `#${sectionId}`;
                    link.classList.toggle('active', matches);
                });
            });
        }, {
            rootMargin: '-45% 0px -45% 0px',
            threshold: 0.1
        });

        observedSections.forEach((section) => observer.observe(section));
    }

    if (historyFilter && historyRows.length) {
        const filterHistory = () => {
            const query = historyFilter.value.trim().toLowerCase();

            historyRows.forEach((row) => {
                const haystack = row.getAttribute('data-history-text') || '';
                row.style.display = haystack.includes(query) ? '' : 'none';
            });
        };

        historyFilter.addEventListener('input', filterHistory);
    }

    if (searchInput && searchRows.length) {
        const filterSearch = () => {
            const query = searchInput.value.trim().toLowerCase();

            searchRows.forEach((row) => {
                const haystack = row.getAttribute('data-search-text') || '';
                row.style.display = haystack.includes(query) ? '' : 'none';
            });
        };

        searchInput.addEventListener('input', filterSearch);
    }
});
