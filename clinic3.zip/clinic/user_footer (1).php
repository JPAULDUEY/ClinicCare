<!-- Newsletter Section -->
<div class="newsletter">
  <div class="box-detail">
    <h1>Subscribe to our Newsletter</h1>
    <p>A place of hope, healing, and compassion.
    Together, we care for your well-being.</p>
    <div class="input-field">
      <input type="email" placeholder="Enter your email..." class="box"> <!-- Fixed input placeholder -->
      <button class="btn">Subscribe</button>
    </div>
    <div class="icons">
      <!-- Corrected icon classes -->
      <i class="bx bxl-facebook"></i>
      <i class="bx bxl-instagram-alt"></i>
      <i class="bx bxl-linkedin"></i>
      <i class="bx bxl-twitter"></i>
      <i class="bx bxl-pinterest-alt"></i>
    </div>
  </div>
</div>

<!-- Footer Section -->
<footer>
  <div class="content">
    <div class="box">
      <!-- Correct logo path -->
      <img width="200" height="50" src="components/image/cliniccare.png"> <!-- Removed space and parentheses -->
      <p>We're always in search for talented and motivated people. Don't be shy introduce yourself!</p>
      <a href="contact.php" class="btn">contact with us</a>
    </div>
    <div class="box">
      <h3>my account</h3>
      <a href="#"><i class="bx bx-chevron-right"></i>my account</a>
      <a href="#"><i class="bx bx-chevron-right"></i>appointments</a> <!-- Fixed spelling -->
      <a href="#"><i class="bx bx-chevron-right"></i>contact us</a>
      <a href="#"><i class="bx bx-chevron-right"></i>newsletter</a>
    </div>
    <div class="box">
      <h3>information</h3>
      <a href="#"><i class="bx bx-chevron-right"></i>about us</a>
      <a href="#"><i class="bx bx-chevron-right"></i>our team</a> <!-- Fixed spelling -->
      <a href="#"><i class="bx bx-chevron-right"></i>privacy policy</a>
      <a href="#"><i class="bx bx-chevron-right"></i>terms & conditions</a>
    </div>
    <div class="box">
      <h3>information</h3>
      <a href="#"><i class="bx bx-chevron-right"></i>our doctors</a>
      <a href="#"><i class="bx bx-chevron-right"></i>affiliate</a> <!-- Fixed spelling -->
      <a href="#"><i class="bx bx-chevron-right"></i>special</a>
      <a href="#"><i class="bx bx-chevron-right"></i>choose us</a>
    </div>
    <div class="box">
      <h3>contact us</h3>
      <a href="#"><i class="bx bxs-phone"></i>+649690451477</a>
      <a href="#"><i class="bx bx-envelope"></i>rainsalcedo@gmail.com</a> <!-- Fixed spelling -->
      <a href="#"><i class="bx bx-chevron-right"></i>Dagupan City, Philippines</a>
      <div class="icons">
      <!-- Corrected icon classes -->
      <i class="bx bxl-facebook"></i>
        <i class="bx bxl-instagram-alt"></i>
        <i class="bx bxl-linkedin"></i>
        <i class="bx bxl-twitter"></i>
        <i class="bx bxl-pinterest-alt"></i>
      </div>
    </div>
  </div>
  <div class="bottom">
    <p>All Right Reserved</p>
  </div>
</footer> <!-- Fixed closing tag -->