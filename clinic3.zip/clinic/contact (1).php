<?php
    include 'components/connect.php';

    if (isset($_COOKIE['user_id'])) {
    	$user_id = $_COOKIE['user_id'];
    }else{
    	$user_id = '';
    }

    if (isset($_POST['send_msg'])) {

        if ($user_id !='') {
        $id = unique_id();

        $name = $_POST['name'];
        $name = filter_var($name, FILTER_SANITIZE_STRING);

        $email = $_POST['email'];
        $email = filter_var($email, FILTER_SANITIZE_STRING);

        $subject = $_POST['subject'];
        $subject = filter_var($subject, FILTER_SANITIZE_STRING);

        $message = $_POST['message'];
        $message = filter_var($message, FILTER_SANITIZE_STRING);

        $verify_message = $conn->prepare("SELECT * FROM `message` WHERE user_id = ? AND name = ? AND email = ? AND subject = ? AND message = ?");
        $verify_message->execute([$user_id, $name, $email, $subject, $message]);

        if ($verify_message->rowCount() > 0) {
            $warning_msg[] = 'message already sent';
        }else{
            $insert_message = $conn->prepare("INSERT INTO `message`(id, user_id, name, email, subject, message) VALUES (?,?,?,?,?,?)");
            $insert_message->execute([$id, $user_id, $name, $email, $subject, $message]);

            $success_msg[] = 'message sent successfully';
            }
        }

        $warning_msg[] = "please login first";

    }
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>ClinicCare</title>
	<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
	<link rel="stylesheet" type="text/css" href="css/user_style.css?v=<?php echo "time"; ?>">
</head>
<body>

    <?php include 'components/user_header.php'; ?>

<section class="contactus-section">
    <div class="content">
            <h3>Contact Us</h3>
            <span>Where every patient is treated with kindness, respect, and care.</span>
            <p>Whether you need to book an appointment, ask a question, or learn more about our<br>services, our team is here to help. You can reach us by phone, email, or visit us in person.
            <br>We are committed to providing prompt and compassionate support to all our patients and visitors.</p>
            <a href="home.php" class="btn">Home</a>
        </div>
</section>

<div class="contact">
    <div class="heading">
        <h1>Contact Us</h1>
        <p></p>
    </div>
    <div class="box-container">
        <div class="box">
            <form action="" method="post">
                <div class="input-field">
                    <p>your name<span>*</span></p>
                    <input type="text" name="name" placeholder="Enter your name" maxlength="50" required class="box">
                </div>
                 <div class="input-field">
                    <p>your email<span>*</span></p>
                    <input type="email" name="email" placeholder="Enter your email" maxlength="80" required class="box">
                </div>
                 <div class="input-field">
                    <p>subject<span>*</span></p>
                    <input type="text" name="subject" placeholder="subject" maxlength="50" required class="box">
                </div>
                <div class="input-field">
                    <p>your message<span>*</span></p>
                    <textarea name="message" class="box"></textarea>
                </div>
                <button type="submit" name="send_msg" class="btn">send message</button>
            </form>
        </div>
        <div class="box">
        </div>
    </div>
</div>

<div class="services">
    <div class="heading">
        <h1>our contact details</h1>
        <p>Whether you need to book an appointment, ask a question, or learn more about our services, our team is here to help</p>
    </div>
    <div class="box-container">
        <div class="box">
            <img width="100px" height="100" src="components/image/call.png">
            <div>
                <h4>emergency call</h4>
                <p>(02) 8722-0650</p>
                <p>911</p>
            </div>
        </div>
        <div class="box">
            <img width="100px" height="100" src="components/image/address.png">
            <div>
                <h4>address</h4>
                <p>329 MAC ARTHUR HIGHWAY, Dagupan City, 2400 Pangasinan</p>
            </div>
        </div>
        <div class="box">
            <img width="100px" height="100" src="components/image/email2.png">
            <div>
                <h4>email</h4>
                <p>ClinicCare@gmail.com</p>
                <p>cliniccare@gmail.com</p>
            </div>
        </div>
    </div>
</div>


<?php include 'components/user_footer.php'; ?>
<!----sweetalert cdn link----->
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<!-----------custom js link------------->
<script type="text/javascript" src="js/user_script.js"></script>

<?php include 'components/alert.php'; ?>
</body>
</html>