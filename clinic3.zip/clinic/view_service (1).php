<?php
    include '../components/connect.php';

    if (isset($_COOKIE['admin_id'])) {
        $admin_id = $_COOKIE['admin_id'];
    }else{
        $admin_id = '';
        header('location:login.php');
    }

    

?>
<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>ClinicCare</title>
   <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
   <link rel="stylesheet" type="text/css" href="../css/admin_style.css?v=<?php echo "time"; ?>">
</head>
<body>

    <?php include '../components/admin_header.php'; ?>

    <section class="view-service-section">
    <div class="content">
            <h3>View service</h3>
            <p>ClinicCare is a trusted healthcare provider offering quality medical services<br>
            with compassion and professionalism.
            <br>Our experienced team delivers personalized care using modern technology to ensure your health and well-being</p>
            <a href="dashboard.php" class="btn">View service</a>
        </div>
    </section>

    <div class="show-container">
        <div class="heading">
        </div>
        <div class="box-container">
            <?php 
                $select_services = $conn->prepare("SELECT * FROM `services`");
                $select_services->execute();

                if ($select_services->rowCount() > 0) {
                    while ($fetch_services = $select_services->fetch(PDO::FETCH_ASSOC)) {
                        
            
            ?>
            <div class="box">
                <form action="" method="post" class="box">
                    <input type="hidden" name="service_id" value="<?= $fetch_services['id']; ?>">

                    <?php if($fetch_services['image'] != '') { ?>
                        <img src="../uploaded_files/<?= $fetch_services['image']; ?>">
                    <?php } ?>

                    <div class="status" style="color: <?php if($fetch_services['status'] == 'active'){echo "limegreen";}else{echo "red";} ?>;"><?= $fetch_services['status']; ?></div>
                    <p class="price">$<?= $fetch_services['price']; ?>/-</p>
                    <div class="content">
                        <div class="title"><?= $fetch_services['name']; ?></div>
                        <div class="flex-btn">
                            <a href="edit_service.php?id=<?= $fetch_services['id']; ?>" class="btn">edit</a>
                            <button type="submit" name="delete" class="btn" onclick="return "></button>
                        </div>
                    </div>
                </form>
            </div>
            <?php 
            }
                }else{
                    echo'
                        <div class="empty">
                            <p>no services added yet! <br><a href="add_service.php" class="btn" style="margin-top: 1rem;">Add service</a></p>
                        </div>
                    ';
                }
            ?>
        </div>
    </div>


    







<!----sweetalert cdn link----->
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<!-----------custom js link------------->
<script type="text/javascript" src="../js/admin_script.js"></script>

<?php include '../components/admin_footer.php'; ?>
</body>
</html>