<?php
session_start();
include 'components/connect.php';

$warning_msg = [];
if (isset($_POST['login'])) {
    $role = $_POST['role'] ?? 'patient';
    $identifier = trim($_POST['identifier'] ?? '');
    $password = trim($_POST['pass'] ?? '');

    if ($identifier === '' || $password === '') {
        $warning_msg[] = 'Please provide credentials.';
    } else {
        $hashedPass = sha1($password);

        switch ($role) {
            case 'admin':
                $stmt = $conn->prepare("SELECT * FROM `admin` WHERE (email = ? OR name = ?) AND password = ? LIMIT 1");
                $stmt->execute([$identifier, $identifier, $hashedPass]);
                if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $_SESSION['admin_id'] = $row['id'];
                    $_SESSION['admin_name'] = $row['name'];
                    setcookie('admin_id', $row['id'], time() + 60 * 60 * 24 * 30, '/');
                    header('Location: admin/dashboard.php');
                    exit;
                }
                break;

            case 'doctor':
                // Debug: Check what we're looking for
                echo "<!-- DEBUG: Looking for doctor with identifier: $identifier -->";
                
                // Try plain text password first (your DB has plain text)
                $stmt = $conn->prepare("SELECT * FROM `doctors` WHERE (email = ? OR name = ?) AND password = ? LIMIT 1");
                $stmt->execute([$identifier, $identifier, $password]);
                
                if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $_SESSION['doctor_id'] = $row['id'];
                    $_SESSION['doctor_name'] = $row['name'];
                    $_SESSION['doctor_email'] = $row['email'];
                    setcookie('doctor_id', $row['id'], time() + 60 * 60 * 24 * 30, '/');
                    header('Location: doctor/dashboard.php');
                    exit;
                }
                
                // If that fails, try hashed
                $stmt = $conn->prepare("SELECT * FROM `doctors` WHERE (email = ? OR name = ?) AND password = ? LIMIT 1");
                $stmt->execute([$identifier, $identifier, $hashedPass]);
                
                if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $_SESSION['doctor_id'] = $row['id'];
                    $_SESSION['doctor_name'] = $row['name'];
                    $_SESSION['doctor_email'] = $row['email'];
                    setcookie('doctor_id', $row['id'], time() + 60 * 60 * 24 * 30, '/');
                    header('Location: doctor/dashboard.php');
                    exit;
                }
                break;

            case 'patient':
                // Try hashed password first for patients
                $stmt = $conn->prepare("SELECT * FROM `patients` WHERE email = ? AND password = ? LIMIT 1");
                $stmt->execute([$identifier, $hashedPass]);
                
                if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $_SESSION['patient_id'] = $row['id'];
                    $_SESSION['patient_name'] = $row['name'];
                    $_SESSION['patient_email'] = $row['email'];
                    setcookie('patient_id', $row['id'], time() + 60 * 60 * 24 * 30, '/');
                    setcookie('user_id', $row['id'], time() + 60 * 60 * 24 * 30, '/');
                    header('Location: patient/dashboard.php');
                    exit;
                }
                
                // Try plain text
                $stmt = $conn->prepare("SELECT * FROM `patients` WHERE email = ? AND password = ? LIMIT 1");
                $stmt->execute([$identifier, $password]);
                
                if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $_SESSION['patient_id'] = $row['id'];
                    $_SESSION['patient_name'] = $row['name'];
                    $_SESSION['patient_email'] = $row['email'];
                    setcookie('patient_id', $row['id'], time() + 60 * 60 * 24 * 30, '/');
                    setcookie('user_id', $row['id'], time() + 60 * 60 * 24 * 30, '/');
                    header('Location: patient/dashboard.php');
                    exit;
                }
                break;
        }

        $warning_msg[] = 'Incorrect credentials for selected role.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ClinicCare | Sign In</title>
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/user_style.css?v=<?php echo time(); ?>">
</head>
<body class="auth-body">
    <a href="home.php" class="auth-back"><i class='bx bx-arrow-back'></i> Back to Home</a>
    <main class="auth-wrapper">
        <div class="auth-card">
            <div class="auth-logo">
                <img src="components/image/logo.png" alt="ClinicCare">
            </div>
            <h1>Member Sign In</h1>
            <form method="post" class="auth-form">
                <div class="role-switch">
                    <label>
                        <input type="radio" name="role" value="patient" checked>
                        Patient
                    </label>
                    <label>
                        <input type="radio" name="role" value="doctor">
                        Doctor
                    </label>
                    <label>
                        <input type="radio" name="role" value="admin">
                        Admin
                    </label>
                </div>
                <label>Username or Email
                    <input type="text" name="identifier" placeholder="Enter username or email" maxlength="70" required>
                </label>
                <label>Password
                    <input type="password" name="pass" placeholder="Enter password" maxlength="50" required>
                </label>
                <label class="remember">
                    <input type="checkbox" name="remember"> Remember me
                </label>
                <button type="submit" name="login" class="btn primary">Sign In</button>
            </form>
            <p class="auth-note">
                <span id="patient-link">New patient? <a href="patient/register.php">Register here</a></span>
                <span id="doctor-link" style="display:none;">New doctor? <a href="doctor/register.php">Register here</a></span>
                <span id="admin-link" style="display:none;">Admin access only</span>
                | Need help? Contact your administrator.
            </p>
        </div>
    </main>
<?php include 'components/alert.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const roleInputs = document.querySelectorAll('input[name="role"]');
    const patientLink = document.getElementById('patient-link');
    const doctorLink = document.getElementById('doctor-link');
    const adminLink = document.getElementById('admin-link');

    roleInputs.forEach(input => {
        input.addEventListener('change', function() {
            // Hide all links first
            patientLink.style.display = 'none';
            doctorLink.style.display = 'none';
            adminLink.style.display = 'none';

            // Show appropriate link based on selection
            if (this.value === 'patient') {
                patientLink.style.display = 'inline';
            } else if (this.value === 'doctor') {
                doctorLink.style.display = 'inline';
            } else if (this.value === 'admin') {
                adminLink.style.display = 'inline';
            }
        });
    });
});
</script>
</body>
</html>
